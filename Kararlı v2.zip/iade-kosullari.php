<?php
$page_title = 'İade ve Değişim Koşulları';
$page_canonical = 'iade-kosullari.php';
$page_og_type = 'article';
$page_og_title = 'İade ve Değişim Koşulları';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">İade ve Değişim Koşulları</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Sorun mu var? Birlikte çözelim.</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler Yönetmeliği
                kapsamında iade ve değişim süreçleri aşağıda açıklanmıştır.
            </p>

            <div class="story-block">
                <h3>Dijital ürünler (oyun anahtarı ve dijital hesaplar)</h3>
                <ul>
                    <li>
                        Mesafeli Sözleşmeler Yönetmeliği madde 15/1-ğ gereği; dijital ürünlerin teslimi ile
                        <strong>cayma hakkı sona erer</strong>. Bu istisna, ürünü sipariş ederken peşinen
                        kabul etmiş sayılırsınız.
                    </li>
                    <li>
                        <strong>Hatalı, çalışmayan veya erişilemeyen</strong> anahtar/hesaplarda ayıplı mal
                        hükümleri uygulanır: ücretsiz <strong>değişim</strong> ya da bedel <strong>iadesi</strong>
                        yapılır. Değişim öncelikli çözümdür.
                    </li>
                    <li>
                        Destek için sipariş numaranız, ürün adı ve sorunun ekran görüntüsü ile birlikte
                        <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                        adresine veya WhatsApp hattımıza yazın.
                    </li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Fiziksel ürünler (ekipman ve baskılı ürünler)</h3>
                <ul>
                    <li>Teslim tarihinden itibaren <strong>14 gün</strong> içinde cayma hakkınızı kullanabilirsiniz.</li>
                    <li>Ürünün kullanılmamış, yeniden satılabilir durumda ve orijinal ambalajında olması gerekir.</li>
                    <li>
                        <strong>Kişiye özel tasarlanan/baskılanan ürünlerde</strong> (yönetmelik madde 15/1-ç)
                        cayma hakkı bulunmamaktadır.
                    </li>
                    <li>Cayma hâlinde iade kargo bedeli Alıcı'ya aittir; üründe ayıp varsa kargo bedeli Satıcı tarafından karşılanır.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>İade süreci</h3>
                <ol>
                    <li>Talebinizi e-posta veya WhatsApp üzerinden iletin (sipariş numarası + açıklama).</li>
                    <li>Ekibimiz talebinizi inceler ve en kısa sürede dönüş yapar.</li>
                    <li>Onay hâlinde fiziksel ürünlerde kargo yönlendirmesi yapılır; dijital ürünlerde değişim veya iade başlatılır.</li>
                    <li>
                        Bedel iadesi, onay tarihinden itibaren en geç <strong>14 gün</strong> içinde ödeme
                        yaptığınız araca yapılır. Bankanızın işlem süresi bu süreye dâhil değildir.
                    </li>
                </ol>
            </div>

            <div class="story-block">
                <h3>İade edilemeyecek durumlar</h3>
                <ul>
                    <li>Teslim edilen dijital anahtar/hesap bilgisi kullanılmış, aktivasyon yapılmış veya üçüncü kişilerle paylaşılmış ise.</li>
                    <li>Kişiye özel üretilen baskılı ürünlerde (istisna: üründe üretim hatası/ayıp olması).</li>
                    <li>Kullanıcı kaynaklı hasar görmüş fiziksel ürünlerde.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>İletişim</h3>
                <p>
                    İade ve değişim talepleriniz için:
                    <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a> ·
                    WhatsApp hattımız ·
                    <?php echo e($hq_address); ?>
                </p>
            </div>

            <p class="legal-note">
                Ürünle ilgili bir sorun yaşadığınızda önce bizimle iletişime geçin; çözümü birlikte bulalım.
                Yasal haklarınız saklıdır.
            </p>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
