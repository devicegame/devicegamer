<?php
$page_title = 'Mesafeli Satış Sözleşmesi';
$page_canonical = 'mesafeli-satis.php';
$page_og_type = 'article';
$page_og_title = 'Mesafeli Satış Sözleşmesi';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">Mesafeli Satış Sözleşmesi</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Elektronik ortamda onaylanır.</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                İşbu sözleşme; 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler
                Yönetmeliği hükümlerine uygun olarak, elektronik ortamda kurulmuştur.
            </p>

            <div class="story-block">
                <h3>MADDE 1 – Taraflar</h3>
                <?php include 'legal-satici.php'; ?>
                <p>
                    <strong>Alıcı:</strong> Sipariş formunda ad soyad, e-posta ve diğer bilgileri belirtilen
                    gerçek veya tüzel kişi. Alıcı bilgileri sipariş özetinde yer alır.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 2 – Konu</h3>
                <p>
                    İşbu sözleşmenin konusu; Alıcı'nın Satıcı'ya ait internet sitesi üzerinden elektronik
                    ortamda siparişini verdiği, nitelikleri ve satış fiyatı sipariş özetinde belirtilen
                    ürün(ler)in satışı ve teslimi ile ilgili olarak tarafların hak ve yükümlülüklerinin
                    belirlenmesidir.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 3 – Sözleşme konusu ürün ve hizmetler</h3>
                <p>
                    Ürünün türü, adedi, vergiler dâhil satış bedeli, ödeme şekli ve teslimat bilgileri,
                    sipariş onayı ile birlikte Alıcı'ya iletilen sipariş özetinde belirtilmiştir.
                </p>
                <ul>
                    <li><strong>Dijital ürünler</strong> (oyun anahtarları, dijital hesaplar): ödemenin onaylanmasından sonra e-posta veya WhatsApp üzerinden dijital olarak teslim edilir.</li>
                    <li><strong>Fiziksel ürünler</strong> (ekipman ve baskılı ürünler): ödeme onayından sonra kargo ile gönderilir.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>MADDE 4 – Genel hükümler</h3>
                <ol>
                    <li>Alıcı, <a class="text-link" href="on-bilgilendirme.php">Ön Bilgilendirme Formu</a>'nu okuyup bilgi sahibi olduğunu ve elektronik ortamda gerekli teyidi verdiğini kabul eder.</li>
                    <li>Sözleşme, Alıcı'nın siparişi elektronik ortamda onaylaması ile kurulur.</li>
                    <li>Dijital ürünlerde teslimat, ödemenin onaylanmasının ardından yapılır. Alıcı, teslim edilen anahtar ve hesap bilgilerini gizli tutmakla ve üçüncü kişilerle paylaşmamakla yükümlüdür.</li>
                    <li>Siparişin zamanında ifa edilememesi hâlinde Satıcı, Alıcı'yı bilgilendirir; ödeme yapılmışsa en geç 14 gün içinde iade edilir.</li>
                </ol>
            </div>

            <div class="story-block">
                <h3>MADDE 5 – Cayma hakkı</h3>
                <p>
                    Alıcı, teslim tarihinden itibaren <strong>14 gün</strong> içinde hiçbir gerekçe
                    göstermeksizin ve cezai şart ödemeksizin sözleşmeden cayma hakkına sahiptir. Cayma
                    bildirimi; <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                    adresine, WhatsApp hattımıza veya satıcı adresine yazılı olarak yapılır. Bildirim süresi
                    içinde gönderilmiş sayılır.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 6 – Cayma hakkı istisnaları</h3>
                <p>Mesafeli Sözleşmeler Yönetmeliği madde 15 uyarınca aşağıdaki durumlarda cayma hakkı kullanılamaz:</p>
                <ul>
                    <li>Fiyatı finansal piyasalardaki dalgalanmalara bağlı olarak değişen ve satıcının kontrolünde olmayan mallar.</li>
                    <li>Alıcı'nın istekleri veya kişisel ihtiyaçları doğrultusunda hazırlanan, üzerinde değişiklik ya da ilave yapılarak <strong>kişiye özel hâle getirilen ürünler</strong> (kişiye özel baskı ve tasarımlar).</li>
                    <li><strong>Elektronik ortamda anında ifa edilen hizmetler veya tüketiciye anında teslim edilen gayrimaddi mallar.</strong> Bu kapsamda; teslim edilen <strong>dijital oyun anahtarı ve dijital hesaplarda</strong>, ürünün Alıcı'ya iletilmesi ile cayma hakkı sona erer. Alıcı, bu istisnayı peşinen kabul eder.</li>
                    <li>Cayma hakkı süresi sona ermeden, tüketicinin onayı ile ifasına başlanan hizmetler.</li>
                </ul>
                <p>
                    Hatalı, çalışmaya elverişsiz veya sözleşmeye aykırı ürünlerde ayıplı mal hükümleri
                    uygulanır; bkz. <a class="text-link" href="iade-kosullari.php">İade ve Değişim Koşulları</a>.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 7 – Cayma hakkının sonuçları</h3>
                <p>
                    Cayma bildiriminden itibaren en geç 20 gün içinde ürünün bedeli, Alıcı'nın ödeme yaptığı
                    araçla iade edilir. Cayma hâlinde iade masrafı, ayıplı ürün durumları dışında Alıcı'ya
                    aittir. Dijital ürünlerde, anahtar paylaşılmış veya kullanılmışsa iade talebi karşılanamaz.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 8 – Alıcının yükümlülükleri</h3>
                <ul>
                    <li>Sipariş bedelini ödeme yöntemi çerçevesinde ödemek.</li>
                    <li>Ürünü, amacına ve kullanım kurallarına uygun kullanmak.</li>
                    <li>Teslim edilen dijital bilgileri (anahtar, hesap) gizli tutmak; paylaşmamak ve yayımlamamak.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>MADDE 9 – Kişisel veriler</h3>
                <p>
                    Kişisel verilerin işlenmesi, aktarılması ve saklanmasına ilişkin ayrıntılar için
                    <a class="text-link" href="kvkk.php">KVKK Aydınlatma Metni</a>'ni inceleyebilirsiniz.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 10 – Uyuşmazlıkların çözümü</h3>
                <p>
                    İşbu sözleşmeden doğabilecek uyuşmazlıklarda, ilgili mevzuatta belirtilen parasal
                    sınırlar dâhilinde Alıcı'nın yerleşim yerindeki veya işlemin yapıldığı yerdeki Tüketici
                    Hakem Heyetleri ile Tüketici Mahkemeleri yetkilidir.
                </p>
            </div>

            <div class="story-block">
                <h3>MADDE 11 – Yürürlük</h3>
                <p>
                    İşbu sözleşme, Alıcı'nın siparişi elektronik ortamda onaylaması ile yürürlüğe girer.
                    Sipariş kayıtları, e-posta ve WhatsApp yazışmaları taraflar arasında delil niteliğindedir.
                </p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
