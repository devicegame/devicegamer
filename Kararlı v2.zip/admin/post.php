<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/_postlib.php';

/**
 * Sosyal Medya Post Oluşturucu
 * Ürün için paylaşım görseli (PNG) üretir ve paylaşım metnini hazırlar.
 */
$id = (int)($_GET['id'] ?? 0);
$data = dg_read_data();
$items = dg_enrich_store_items($data, dg_sort_newest($data['store_items'] ?? []));
$it = null;
foreach ($items as $row) {
    if ((int)($row['id'] ?? 0) === $id) { $it = $row; break; }
}
if (!$it) {
    flash_error_set('Ürün bulunamadı.');
    header('Location: store.php');
    exit;
}

$cfg = dg_post_design($it);
$defaultCaption = dg_post_caption($cfg);

admin_head('Post Oluştur — ' . $it['name']);
?>
<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:16px">
  <div>
    <h1 style="font-size:22px;margin:0">📣 Sosyal Medya Post Oluşturucu</h1>
    <div class="dg-muted" style="font-size:12px;margin-top:4px">
      <a href="store.php" style="color:inherit">← Mağaza yönetimi</a> · Ürün: <b><?= e($it['name']) ?></b> · ID #<?= (int)$it['id'] ?>
    </div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="dg-btn dg-btn-ghost" href="post-bulk.php">📦 Toplu Post Paketi</a>
    <button type="button" id="btnDownload" class="dg-btn dg-btn-primary">⬇ Görseli indir (PNG)</button>
    <button type="button" id="btnCopy" class="dg-btn dg-btn-ghost">📋 Metni kopyala</button>
    <a class="dg-btn dg-btn-ghost" href="post.php?id=<?= (int)$it['id'] ?>">↺ Yenile</a>
  </div>
</div>

<div style="display:grid;grid-template-columns:minmax(0,340px) minmax(0,1fr);gap:16px;align-items:start">

  <!-- SOL: ayarlar -->
  <div class="dg-card" style="padding:16px;display:flex;flex-direction:column;gap:12px">
    <div>
      <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">Görsel formatı</div>
      <div style="display:flex;gap:8px">
        <button type="button" class="dg-btn dg-btn-primary fmt-btn" data-fmt="kare" style="flex:1">◻ Kare<br><small>1080×1080</small></button>
        <button type="button" class="dg-btn dg-btn-ghost fmt-btn" data-fmt="yatay" style="flex:1">▭ Yatay<br><small>1200×630</small></button>
        <button type="button" class="dg-btn dg-btn-ghost fmt-btn" data-fmt="story" style="flex:1">📱 Story<br><small>1080×1920</small></button>
      </div>
    </div>

    <label class="dg-field"><span>Görseldeki başlık</span>
      <input type="text" id="fTitle" value="<?= e($it['name']) ?>"></label>

    <label class="dg-field"><span>Alt metin (görselde)</span>
      <input type="text" id="fSub" value="<?= e($cfg['desc']) ?>"></label>

    <label class="dg-field"><span>CTA (çağrı metni)</span>
      <input type="text" id="fCta" value="Hemen sipariş ver!"></label>

    <label class="dg-field"><span>Hashtag'ler</span>
      <input type="text" id="fTags" value="#devicegame #oyun #gaming #oyunkey #indirim"></label>

    <label class="dg-check"><input type="checkbox" id="fPrice" checked> <span>Fiyat rozetini göster</span></label>
    <label class="dg-check"><input type="checkbox" id="fDesc" checked> <span>Alt metni göster</span></label>

    <div>
      <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin:6px 0">Paylaşım metni</div>
      <textarea id="fCaption" rows="12" style="width:100%;box-sizing:border-box;background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:12px;padding:12px;font:500 12px/1.65 inherit;resize:vertical"><?= e($defaultCaption) ?></textarea>
      <button type="button" id="btnRegen" class="dg-btn dg-btn-ghost dg-btn-sm" style="margin-top:8px;width:100%">Metni alanlardan yeniden oluştur</button>
    </div>

    <div>
      <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">Hızlı paylaş</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button type="button" class="dg-btn dg-btn-ghost dg-btn-sm sh-btn" data-net="x">𝕏 X</button>
        <button type="button" class="dg-btn dg-btn-ghost dg-btn-sm sh-btn" data-net="whatsapp">WhatsApp</button>
        <button type="button" class="dg-btn dg-btn-ghost dg-btn-sm sh-btn" data-net="telegram">Telegram</button>
        <button type="button" class="dg-btn dg-btn-ghost dg-btn-sm sh-btn" data-net="facebook">Facebook</button>
      </div>
      <div class="dg-muted" style="font-size:11px;margin-top:8px;line-height:1.6">
        Instagram için: görseli indirip metni kopyalayın ve uygulamadan paylaşın.
      </div>
    </div>
  </div>

  <!-- SAĞ: önizleme -->
  <div class="dg-card" style="padding:16px">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <b style="font-size:13px">Canlı önizleme</b>
      <span class="dg-muted" style="font-size:11px">İndirilen PNG tam çözünürlüktedir</span>
    </div>
    <div style="background:var(--card2);border:1px solid var(--line);border-radius:16px;padding:16px;display:flex;justify-content:center">
      <canvas id="postCanvas" style="width:100%;max-width:640px;height:auto;border-radius:12px;box-shadow:0 18px 50px rgba(0,0,0,.35)"></canvas>
    </div>
  </div>
</div>

<script src="post-render.js"></script>
<script>
(function () {
  'use strict';
  var cfg = <?= json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var format = 'kare';
  var loadedImg = null;

  var cv = document.getElementById('postCanvas');

  function $(id) { return document.getElementById(id); }

  function render() {
    DGPost.render(cv, cfg, format, {
      title: $('fTitle').value.trim() || cfg.name,
      sub: $('fSub').value.trim(),
      showPrice: $('fPrice').checked,
      showDesc: $('fDesc').checked
    }, loadedImg);
  }

  DGPost.resolveImage(cfg).then(function (im) {
    loadedImg = im;
    render();
  });

  // ---- Olaylar ----
  document.querySelectorAll('.fmt-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      format = b.getAttribute('data-fmt');
      document.querySelectorAll('.fmt-btn').forEach(function (x) {
        x.classList.remove('dg-btn-primary'); x.classList.add('dg-btn-ghost');
      });
      b.classList.remove('dg-btn-ghost'); b.classList.add('dg-btn-primary');
      render();
    });
  });

  ['fTitle', 'fSub', 'fCta', 'fPrice', 'fDesc'].forEach(function (id) {
    $(id).addEventListener('input', render);
    $(id).addEventListener('change', render);
  });

  $('btnRegen').addEventListener('click', function () {
    $('fCaption').value = DGPost.buildCaption(cfg, {
      title: $('fTitle').value.trim() || cfg.name,
      sub: $('fSub').value.trim(),
      tags: $('fTags').value.trim()
    });
  });

  $('btnCopy').addEventListener('click', function () {
    var text = $('fCaption').value;
    function done() {
      var b = $('btnCopy'); var old = b.textContent;
      b.textContent = '✓ Kopyalandı';
      setTimeout(function () { b.textContent = old; }, 1600);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done);
    } else {
      $('fCaption').select();
      document.execCommand('copy');
      done();
    }
  });

  $('btnDownload').addEventListener('click', function () {
    cv.toBlob(function (blob) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'dg-post-' + cfg.id + '-' + format + '.png';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
    }, 'image/png');
  });

  document.querySelectorAll('.sh-btn').forEach(function (b) {
    b.addEventListener('click', function () {
      var net = b.getAttribute('data-net');
      var text = $('fCaption').value;
      var u = '';
      if (net === 'x') u = 'https://twitter.com/intent/tweet?text=' + encodeURIComponent(text);
      else if (net === 'whatsapp') u = 'https://wa.me/?text=' + encodeURIComponent(text);
      else if (net === 'telegram') u = 'https://t.me/share/url?url=' + encodeURIComponent(cfg.purl) + '&text=' + encodeURIComponent(text);
      else if (net === 'facebook') u = 'https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(cfg.purl) + '&quote=' + encodeURIComponent(text);
      if (u) window.open(u, '_blank', 'noopener,width=680,height=620');
    });
  });

  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(render);
  }
  render();
})();
</script>
<?php admin_foot(); ?>
