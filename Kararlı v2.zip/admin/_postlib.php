<?php
/**
 * Post oluşturucu ortak yardımcıları (admin/post.php + admin/post-bulk.php).
 */

/**
 * Ürün için görsel tasarım verisi üretir: renkler, glyph, görsel URL, ürün linki.
 * Eski katalogdaki renk/glyph bilgileri legacy_slug ile eşlenir.
 */
function dg_post_design(array $it): array
{
    // Katalog yalnızca bir kez okunur; 50+ üründe tekrarlı disk okuması sayfayı yavaşlatır.
    static $bySlug = null;
    static $byName = null;
    if ($bySlug === null) {
        $bySlug = [];
        $byName = [];
        foreach (dg_legacy_catalog_from_files() as $lp) {
            $s = (string)($lp['slug'] ?? '');
            if ($s !== '' && !isset($bySlug[$s])) {
                $bySlug[$s] = $lp;
            }
            $n = mb_strtolower((string)($lp['name'] ?? ''), 'UTF-8');
            if ($n !== '' && !isset($byName[$n])) {
                $byName[$n] = $lp;
            }
        }
    }

    $legacy = null;
    $lslug = (string)($it['legacy_slug'] ?? '');
    if ($lslug !== '' && isset($bySlug[$lslug])) {
        $legacy = $bySlug[$lslug];
    }
    if (!$legacy) {
        $lname = mb_strtolower((string)($it['name'] ?? ''), 'UTF-8');
        if (isset($byName[$lname])) {
            $legacy = $byName[$lname];
        }
    }

    $glyph = (string)(($legacy['glyph'] ?? '') ?: '');
    if ($glyph === '') {
        $letters = preg_replace('/[^\p{L}\p{N}]+/u', '', (string)($it['name'] ?? ''));
        $glyph = strtoupper(mb_substr((string)$letters, 0, 2) ?: 'DG');
    }

    $desc = trim((string)($it['description'] ?? ''));
    $descShort = mb_strlen($desc) > 210 ? mb_substr($desc, 0, 207) . '…' : $desc;

    return [
        'id'         => (int)($it['id'] ?? 0),
        'name'       => (string)($it['name'] ?? ''),
        'desc'       => $descShort,
        'priceTl'    => (float)($it['price_tl'] ?? 0),
        'priceDcoin' => (int)($it['price_dcoin'] ?? 0),
        'c1'         => (string)(($legacy['c1'] ?? '') ?: '#221436'),
        'c2'         => (string)(($legacy['c2'] ?? '') ?: '#7c41cd'),
        'accent'     => (string)(($legacy['accent'] ?? '') ?: '#d4f78b'),
        'glyph'      => $glyph,
        'badge'      => mb_strtoupper((string)(($legacy['badge'] ?? '') ?: 'ANINDA TESLİMAT')),
        'platform'   => (string)(($legacy['platform'] ?? '') ?: 'PC'),
        'visual'     => ($v = (trim((string)($it['image_url'] ?? '')) ?: trim((string)($legacy['image'] ?? ''))))
            ? 'img-proxy.php?url=' . rawurlencode($v)
            : '',
        'purl'       => $lslug !== ''
            ? 'https://devicegame.com/product.php?slug=' . rawurlencode($lslug)
            : 'https://devicegame.com/shop.php',
    ];
}

/** Varsayılan paylaşım metni (JS buildCaption ile aynı yapı). */
function dg_post_caption(array $cfg): string
{
    $lines = [];
    $lines[] = '🎮 ' . (string)($cfg['name'] ?? '');
    if ((string)($cfg['desc'] ?? '') !== '') {
        $lines[] = (string)$cfg['desc'];
    }
    $lines[] = '';
    if ((float)($cfg['priceTl'] ?? 0) > 0) {
        $lines[] = '💰 ' . number_format((float)$cfg['priceTl'], 0, ',', '.') . ' TL';
    }
    if ((int)($cfg['priceDcoin'] ?? 0) > 0) {
        $lines[] = '◈ ' . number_format((int)$cfg['priceDcoin'], 0, ',', '.') . ' D-Coin ile de alınabilir';
    }
    $lines[] = '';
    $lines[] = '🚀 Anında teslimat · WhatsApp’tan hızlı sipariş';
    $lines[] = '🛒 ' . (string)($cfg['purl'] ?? '');
    $lines[] = '';
    $lines[] = '#devicegame #oyun #gaming #oyunkey #indirim';
    return implode("\n", $lines);
}
