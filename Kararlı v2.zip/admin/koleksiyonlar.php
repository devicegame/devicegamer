<?php
declare(strict_types=1);
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/../lib/shop.php';
require_once __DIR__ . '/../lib/collections.php';
$products = shop_products(); $catalog = [];
foreach ($products as $product) $catalog[(string)$product['slug']] = $product;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify((string)($_POST['csrf'] ?? ''))) flash_error_set('Güvenlik doğrulaması başarısız.');
    else try {
        $action = (string)($_POST['action'] ?? ''); $id = (string)($_POST['id'] ?? '');
        if ($id !== '' && !preg_match('/^[a-f0-9]{24}$/', $id)) throw new RuntimeException('Geçersiz koleksiyon.');
        if ($action === 'delete') {
            if ($id === '') throw new RuntimeException('Koleksiyon bulunamadı.');
            dg_collections_change(static function (array &$rows) use ($id): void {
                $before=count($rows); $rows=array_values(array_filter($rows, static fn($row): bool => (string)($row['id']??'') !== $id));
                if (count($rows)===$before) throw new RuntimeException('Koleksiyon bulunamadı.');
            });
            flash_set('Koleksiyon silindi. Ürünler mağazadan silinmedi.');
        } elseif ($action === 'save') {
            $title=trim((string)($_POST['title']??'')); $desc=trim((string)($_POST['description']??''));
            if (mb_strlen($title,'UTF-8') < 2 || mb_strlen($title,'UTF-8') > 80 || mb_strlen($desc,'UTF-8') > 500) throw new RuntimeException('Başlık 2–80, açıklama en fazla 500 karakter olmalı.');
            $slugs=[];
            foreach (preg_split('/[\r\n,]+/', (string)($_POST['product_slugs']??'')) ?: [] as $slug) {
                $slug=trim($slug); if ($slug === '') continue;
                if (!isset($catalog[$slug])) throw new RuntimeException('Ürün bulunamadı: ' . mb_substr($slug,0,80,'UTF-8'));
                if (!in_array($slug,$slugs,true)) $slugs[]=$slug;
            }
            if (count($slugs)>200) throw new RuntimeException('Bir koleksiyona en fazla 200 ürün eklenebilir.');
            $row=['id'=>$id ?: bin2hex(random_bytes(12)), 'title'=>$title, 'description'=>$desc, 'products'=>$slugs, 'active'=>!empty($_POST['active']), 'updated_at'=>time()];
            dg_collections_change(static function(array &$rows) use ($id,$row): void {
                if ($id==='') { $row['created_at']=time(); $rows[]=$row; return; }
                foreach ($rows as &$existing) if ((string)($existing['id']??'')===$id) { $row['created_at']=(int)($existing['created_at']??time()); $existing=$row; return; }
                throw new RuntimeException('Koleksiyon bulunamadı.');
            });
            flash_set('Koleksiyon kaydedildi.');
        } else throw new RuntimeException('Geçersiz işlem.');
    } catch(Throwable $e) { error_log('[collections] '.$e->getMessage()); flash_error_set('İşlem tamamlanamadı: '.$e->getMessage()); }
    header('Location: koleksiyonlar.php',true,303); exit;
}
$rows=dg_collections_read(); $editId=(string)($_GET['edit']??''); $edit=null;
foreach($rows as $row) if (($row['id']??'')===$editId) { $edit=$row; break; }
admin_head('Koleksiyonlar');
?>
<h1>🗂 Koleksiyon yönetimi</h1><p class="dg-muted">Ürünleri seçkilerde bir araya getir. Gizli koleksiyonlar ziyaretçilere gösterilmez; koleksiyonu silmek ürünleri silmez.</p>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:18px;margin-top:20px">
<div class="dg-card"><div class="dg-card-body"><h2><?= $edit ? 'Koleksiyonu düzenle' : 'Yeni koleksiyon' ?></h2>
<form method="post" class="dg-form"><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= e($edit['id']??'') ?>">
<label class="dg-field"><span>Başlık</span><input name="title" maxlength="80" required value="<?= e($edit['title']??'') ?>" placeholder="Haftanın fırsatları"></label>
<label class="dg-field"><span>Açıklama</span><textarea name="description" maxlength="500" rows="3"><?= e($edit['description']??'') ?></textarea></label>
<label class="dg-field"><span>Ürün ara ve seç</span><input type="search" id="collection-search" placeholder="Oyun adı veya platform ara" autocomplete="off"></label>
<div id="collection-results" style="max-height:240px;overflow:auto;border:1px solid var(--line);border-radius:12px;margin:8px 0" aria-live="polite"></div>
<label class="dg-field"><span>Seçili ürünler (her satırda bir ürün kodu)</span><textarea name="product_slugs" id="collection-slugs" rows="6" placeholder="Ürün arayıp seçebilir veya ürün kodlarını yazabilirsin."><?= e(implode("\n",(array)($edit['products']??[]))) ?></textarea></label>
<p class="dg-mini">Seçili ürün sayısı: <span id="collection-selected-count">0</span> / 200</p>
<label><input type="checkbox" name="active" value="1" <?= !$edit || !empty($edit['active']) ? 'checked' : '' ?>> Yayında</label>
<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:16px"><button class="dg-btn dg-btn-primary" type="submit">Kaydet</button><?php if ($edit): ?><a href="koleksiyonlar.php" class="dg-btn dg-btn-ghost">İptal</a><?php endif; ?></div>
</form></div></div>
<div class="dg-card"><div class="dg-card-body"><h2>Koleksiyonlar</h2><?php if (!$rows): ?><p>Henüz koleksiyon yok.</p><?php endif; ?>
<?php foreach(array_reverse($rows) as $row): ?><article style="border-top:1px solid var(--line);padding:14px 0"><strong><?= e($row['title']??'') ?></strong> <span class="dg-chip"><?= !empty($row['active']) ? 'Yayında' : 'Gizli' ?></span><p class="dg-mini"><?= count((array)($row['products']??[])) ?> ürün</p><div style="display:flex;gap:8px;flex-wrap:wrap">
<a class="dg-btn dg-btn-ghost dg-btn-sm" href="koleksiyonlar.php?edit=<?= rawurlencode((string)$row['id']) ?>">Düzenle</a>
<?php if (!empty($row['active'])): ?><a class="dg-btn dg-btn-ghost dg-btn-sm" target="_blank" rel="noopener" href="../koleksiyonlar.php?id=<?= rawurlencode((string)$row['id']) ?>">Görüntüle</a><?php endif; ?>
<form method="post" onsubmit="return confirm('Koleksiyon silinsin mi? Ürünler silinmez.')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= e($row['id']) ?>"><button class="dg-btn dg-btn-ghost dg-btn-sm">Sil</button></form></div></article><?php endforeach; ?>
</div></div></div>
<script id="dg-collection-catalog" type="application/json"><?= json_encode(array_map(static fn(array $p): array => ['slug'=>$p['slug'],'name'=>$p['name'],'platform'=>$p['platform']],$products), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?></script>
<script src="../assets/js/collection-admin.js?v=1" defer></script>
<?php admin_foot(); ?>
