/**
 * DGPost — Sosyal medya görsel üretici (ortak canvas motoru).
 * admin/post.php ve admin/post-bulk.php tarafından kullanılır.
 */
window.DGPost = (function () {
  'use strict';

  var FORMATS = {
    kare:  { w: 1080, h: 1080 },
    yatay: { w: 1200, h: 630 },
    story: { w: 1080, h: 1920 }
  };

  var imgCache = {};

  function resolveImage(cfg) {
    return new Promise(function (resolve) {
      var url = cfg && cfg.visual ? String(cfg.visual) : '';
      if (!url) { resolve(null); return; }
      if (Object.prototype.hasOwnProperty.call(imgCache, url)) { resolve(imgCache[url]); return; }
      var im = new Image();
      im.onload = function () { imgCache[url] = im; resolve(im); };
      im.onerror = function () { imgCache[url] = null; resolve(null); };
      im.src = url;
    });
  }

  function hexRgba(hex, a) {
    var h = String(hex || '#000000').replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    if (isNaN(n)) n = 0;
    return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
  }

  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function wrap(ctx, text, maxW, font) {
    ctx.font = font;
    var words = String(text || '').split(/\s+/).filter(Boolean);
    var lines = [], line = '';
    for (var i = 0; i < words.length; i++) {
      var t = line ? line + ' ' + words[i] : words[i];
      if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = words[i]; }
      else line = t;
    }
    if (line) lines.push(line);
    return lines;
  }

  function drawCover(ctx, imgObj, x, y, w, h) {
    var ir = imgObj.width / imgObj.height, br = w / h, sw, sh, sx, sy;
    if (ir > br) { sh = imgObj.height; sw = sh * br; sx = (imgObj.width - sw) / 2; sy = 0; }
    else { sw = imgObj.width; sh = sw / br; sx = 0; sy = (imgObj.height - sh) / 2; }
    ctx.drawImage(imgObj, sx, sy, sw, sh, x, y, w, h);
  }

  function drawPanel(ctx, cfg, img, x, y, size) {
    ctx.save();
    rr(ctx, x, y, size, size, size * 0.07);
    ctx.clip();
    if (img) {
      drawCover(ctx, img, x, y, size, size);
      var vg = ctx.createLinearGradient(x, y + size * 0.55, x, y + size);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,0,0.32)');
      ctx.fillStyle = vg;
      ctx.fillRect(x, y, size, size);
    } else {
      var g = ctx.createLinearGradient(x, y, x + size, y + size);
      g.addColorStop(0, hexRgba(cfg.accent, 0.16));
      g.addColorStop(1, hexRgba(cfg.c1, 0.55));
      ctx.fillStyle = g;
      ctx.fillRect(x, y, size, size);
      ctx.strokeStyle = hexRgba(cfg.accent, 0.35);
      ctx.lineWidth = Math.max(2, size * 0.006);
      for (var i = 1; i <= 3; i++) {
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size * 0.14 * i, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.fillStyle = cfg.accent;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.font = '800 ' + Math.round(size * 0.3) + 'px "Instrument Sans", system-ui, sans-serif';
      ctx.fillText(cfg.glyph, x + size / 2, y + size / 2 + size * 0.02);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'alphabetic';
    }
    ctx.restore();
    ctx.strokeStyle = hexRgba('#ffffff', 0.18);
    ctx.lineWidth = Math.max(2, size * 0.005);
    rr(ctx, x, y, size, size, size * 0.07);
    ctx.stroke();
  }

  function drawBrand(ctx, cfg, pad, baselineY, fontPx) {
    ctx.font = '800 ' + fontPx + 'px "Instrument Sans", system-ui, sans-serif';
    ctx.fillStyle = '#ffffff';
    var t = 'device game';
    ctx.fillText(t, pad, baselineY);
    var w = ctx.measureText(t).width;
    ctx.fillStyle = cfg.accent;
    ctx.fillText('.', pad + w, baselineY);
  }

  function drawChip(ctx, cfg, text, x, y, fontPx, filled) {
    ctx.font = '700 ' + fontPx + 'px "Instrument Sans", system-ui, sans-serif';
    var w = ctx.measureText(text).width + fontPx * 1.9;
    var h = fontPx * 2.35;
    rr(ctx, x, y, w, h, h / 2);
    if (filled) { ctx.fillStyle = cfg.accent; ctx.fill(); ctx.fillStyle = '#14211b'; }
    else {
      ctx.fillStyle = hexRgba('#ffffff', 0.08); ctx.fill();
      ctx.strokeStyle = hexRgba('#ffffff', 0.22); ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#ffffff';
    }
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x + fontPx * 0.95, y + h / 2 + fontPx * 0.08);
    ctx.textBaseline = 'alphabetic';
    return w;
  }

  function drawPriceRow(ctx, cfg, x, y, fontPx) {
    var cx = x;
    if (cfg.priceTl > 0) {
      var t = '₺' + Math.round(cfg.priceTl).toLocaleString('tr-TR');
      ctx.font = '800 ' + fontPx + 'px "Instrument Sans", system-ui, sans-serif';
      var w = ctx.measureText(t).width + fontPx * 2.1;
      var h = fontPx * 2.5;
      rr(ctx, cx, y, w, h, h / 2);
      ctx.fillStyle = cfg.accent; ctx.fill();
      ctx.fillStyle = '#14211b';
      ctx.textBaseline = 'middle';
      ctx.fillText(t, cx + fontPx * 1.05, y + h / 2 + fontPx * 0.06);
      ctx.textBaseline = 'alphabetic';
      cx += w + fontPx * 0.9;
    }
    if (cfg.priceDcoin > 0) {
      var t2 = '◈ ' + Math.round(cfg.priceDcoin).toLocaleString('tr-TR') + ' D-Coin';
      ctx.font = '700 ' + Math.round(fontPx * 0.72) + 'px "Instrument Sans", system-ui, sans-serif';
      var w2 = ctx.measureText(t2).width + fontPx * 1.7;
      var h2 = fontPx * 2.1;
      rr(ctx, cx, y + (fontPx * 2.5 - h2) / 2, w2, h2, h2 / 2);
      ctx.fillStyle = hexRgba('#ffffff', 0.1); ctx.fill();
      ctx.strokeStyle = hexRgba('#ffffff', 0.28); ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#ffffff';
      ctx.textBaseline = 'middle';
      ctx.fillText(t2, cx + fontPx * 0.85, y + fontPx * 1.25 + fontPx * 0.06);
      ctx.textBaseline = 'alphabetic';
    }
  }

  function drawBottom(ctx, cfg, pad, y, w, fontPx) {
    rr(ctx, pad, y, w, fontPx * 3.1, fontPx * 1.55);
    ctx.fillStyle = hexRgba('#ffffff', 0.07); ctx.fill();
    ctx.strokeStyle = hexRgba('#ffffff', 0.16); ctx.lineWidth = 2; ctx.stroke();
    ctx.font = '700 ' + fontPx + 'px "Instrument Sans", system-ui, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textBaseline = 'middle';
    ctx.fillText('🚀 ' + cfg.badge, pad + fontPx * 1.5, y + fontPx * 1.55);
    ctx.textAlign = 'right';
    ctx.fillStyle = cfg.accent;
    ctx.fillText('devicegame.com', pad + w - fontPx * 1.5, y + fontPx * 1.55);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';
  }

  /**
   * Ana çizim fonksiyonu.
   * canvas: <canvas>; cfg: tasarım verisi; format: 'kare'|'yatay'|'story'
   * opts: { title, sub, showPrice, showDesc }; img: yüklü Image ya da null.
   */
  function render(canvas, cfg, format, opts, img) {
    var F = FORMATS[format] || FORMATS.kare;
    canvas.width = F.w;
    canvas.height = F.h;
    var ctx = canvas.getContext('2d');
    var W = F.w, H = F.h;
    opts = opts || {};
    var title = String(opts.title || cfg.name || '');
    var sub = String(opts.sub != null ? opts.sub : (cfg.desc || ''));
    var showPrice = opts.showPrice !== false;
    var showDesc = opts.showDesc !== false && !!sub;

    // Arka plan
    var g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, cfg.c1);
    g.addColorStop(1, cfg.c2);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    var r1 = ctx.createRadialGradient(W * 0.1, H * 0.06, 0, W * 0.1, H * 0.06, W * 0.6);
    r1.addColorStop(0, hexRgba(cfg.accent, 0.14));
    r1.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = r1; ctx.fillRect(0, 0, W, H);

    var r2 = ctx.createRadialGradient(W * 0.94, H * 0.98, 0, W * 0.94, H * 0.98, W * 0.5);
    r2.addColorStop(0, hexRgba(cfg.c2, 0.4));
    r2.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = r2; ctx.fillRect(0, 0, W, H);

    // Nokta dokusu
    var gap = Math.round(W / 42);
    ctx.fillStyle = hexRgba('#ffffff', 0.06);
    for (var yy = gap; yy < H; yy += gap) {
      for (var xx = gap; xx < W; xx += gap) {
        ctx.beginPath(); ctx.arc(xx, yy, Math.max(1.6, W * 0.0022), 0, Math.PI * 2); ctx.fill();
      }
    }

    if (format === 'kare') {
      var pad = Math.round(W * 0.072);
      drawBrand(ctx, cfg, pad, pad + Math.round(W * 0.036), Math.round(W * 0.036));
      var chipText = cfg.platform ? ('MAĞAZA · ' + cfg.platform) : 'MAĞAZA';
      ctx.font = '700 ' + Math.round(W * 0.0155) + 'px "Instrument Sans", system-ui, sans-serif';
      var chipW = ctx.measureText(chipText).width + Math.round(W * 0.0155) * 1.9;
      drawChip(ctx, cfg, chipText, W - pad - chipW, pad - Math.round(W * 0.008), Math.round(W * 0.0155), false);

      var size = Math.round(W * 0.36);
      drawPanel(ctx, cfg, img, (W - size) / 2, Math.round(H * 0.115), size);

      var tY = Math.round(H * 0.55);
      var tFont = '800 ' + Math.round(W * 0.05) + 'px "Instrument Sans", system-ui, sans-serif';
      var tLines = wrap(ctx, title, W - pad * 2, tFont).slice(0, 2);
      ctx.font = tFont; ctx.fillStyle = '#ffffff';
      for (var i = 0; i < tLines.length; i++) ctx.fillText(tLines[i], pad, tY + i * Math.round(W * 0.0555));
      tY += tLines.length * Math.round(W * 0.0555);

      if (showDesc) {
        var sFont = '600 ' + Math.round(W * 0.023) + 'px "Instrument Sans", system-ui, sans-serif';
        var sLines = wrap(ctx, sub, W - pad * 2, sFont).slice(0, 2);
        ctx.font = sFont; ctx.fillStyle = hexRgba('#ffffff', 0.78);
        for (var j = 0; j < sLines.length; j++) ctx.fillText(sLines[j], pad, tY + Math.round(W * 0.027) + j * Math.round(W * 0.03));
        tY += Math.round(W * 0.027) + sLines.length * Math.round(W * 0.03);
      }

      if (showPrice) drawPriceRow(ctx, cfg, pad, tY + Math.round(W * 0.02), Math.round(W * 0.03));
      drawBottom(ctx, cfg, pad, H - pad - Math.round(W * 0.062), W - pad * 2, Math.round(W * 0.02));
    } else if (format === 'yatay') {
      var pad2 = Math.round(H * 0.088);
      var panelSize = Math.round(H * 0.78);
      var panelX = W - pad2 - panelSize;
      drawPanel(ctx, cfg, img, panelX, (H - panelSize) / 2, panelSize);

      var lx = pad2;
      var colW = W - pad2 * 2 - panelSize - Math.round(W * 0.03);
      drawBrand(ctx, cfg, lx, pad2 + Math.round(H * 0.048), Math.round(H * 0.05));

      var tY2 = Math.round(H * 0.29);
      var tFont2 = '800 ' + Math.round(H * 0.075) + 'px "Instrument Sans", system-ui, sans-serif';
      var tLines2 = wrap(ctx, title, colW, tFont2).slice(0, 2);
      ctx.font = tFont2; ctx.fillStyle = '#ffffff';
      for (var k = 0; k < tLines2.length; k++) ctx.fillText(tLines2[k], lx, tY2 + k * Math.round(H * 0.086));
      tY2 += tLines2.length * Math.round(H * 0.086);

      if (showDesc) {
        var sFont2 = '600 ' + Math.round(H * 0.038) + 'px "Instrument Sans", system-ui, sans-serif';
        var sLines2 = wrap(ctx, sub, colW, sFont2).slice(0, 2);
        ctx.font = sFont2; ctx.fillStyle = hexRgba('#ffffff', 0.78);
        for (var m = 0; m < sLines2.length; m++) ctx.fillText(sLines2[m], lx, tY2 + Math.round(H * 0.042) + m * Math.round(H * 0.045));
        tY2 += Math.round(H * 0.042) + sLines2.length * Math.round(H * 0.045);
      }

      if (showPrice) drawPriceRow(ctx, cfg, lx, tY2 + Math.round(H * 0.04), Math.round(H * 0.052));
      drawBottom(ctx, cfg, lx, H - Math.round(H * 0.073) - Math.round(H * 0.105), panelX - lx - Math.round(W * 0.02), Math.round(H * 0.034));
    } else {
      // story (1080×1920)
      var pad3 = Math.round(W * 0.072);
      drawBrand(ctx, cfg, pad3, Math.round(H * 0.12), Math.round(W * 0.041));
      var chipText3 = cfg.platform ? ('MAĞAZA · ' + cfg.platform) : 'MAĞAZA';
      ctx.font = '700 ' + Math.round(W * 0.0185) + 'px "Instrument Sans", system-ui, sans-serif';
      var chipW3 = ctx.measureText(chipText3).width + Math.round(W * 0.0185) * 1.9;
      drawChip(ctx, cfg, chipText3, W - pad3 - chipW3, Math.round(H * 0.12) - Math.round(W * 0.052), Math.round(W * 0.0185), false);

      var size3 = Math.round(W * 0.63);
      drawPanel(ctx, cfg, img, (W - size3) / 2, Math.round(H * 0.167), size3);

      var tY3 = Math.round(H * 0.599);
      var tFont3 = '800 ' + Math.round(W * 0.059) + 'px "Instrument Sans", system-ui, sans-serif';
      var tLines3 = wrap(ctx, title, W - pad3 * 2, tFont3).slice(0, 2);
      ctx.font = tFont3; ctx.fillStyle = '#ffffff';
      for (var p = 0; p < tLines3.length; p++) ctx.fillText(tLines3[p], pad3, tY3 + p * Math.round(W * 0.067));
      tY3 += tLines3.length * Math.round(W * 0.067);

      if (showDesc) {
        var sFont3 = '600 ' + Math.round(W * 0.03) + 'px "Instrument Sans", system-ui, sans-serif';
        var sLines3 = wrap(ctx, sub, W - pad3 * 2, sFont3).slice(0, 2);
        ctx.font = sFont3; ctx.fillStyle = hexRgba('#ffffff', 0.78);
        for (var q = 0; q < sLines3.length; q++) ctx.fillText(sLines3[q], pad3, tY3 + Math.round(W * 0.045) + q * Math.round(W * 0.041));
        tY3 += Math.round(W * 0.045) + sLines3.length * Math.round(W * 0.041);
      }

      if (showPrice) drawPriceRow(ctx, cfg, pad3, tY3 + Math.round(W * 0.037), Math.round(W * 0.039));
      drawBottom(ctx, cfg, pad3, H - Math.round(H * 0.156), W - pad3 * 2, Math.round(W * 0.028));
    }
  }

  function buildCaption(cfg, opts) {
    opts = opts || {};
    var title = String(opts.title || cfg.name || '');
    var sub = String(opts.sub != null ? opts.sub : (cfg.desc || ''));
    var tags = String(opts.tags != null ? opts.tags : '#devicegame #oyun #gaming #oyunkey #indirim');
    var out = [];
    out.push('🎮 ' + title);
    if (sub) out.push(sub);
    out.push('');
    if (cfg.priceTl > 0) out.push('💰 ' + Math.round(cfg.priceTl).toLocaleString('tr-TR') + ' TL');
    if (cfg.priceDcoin > 0) out.push('◈ ' + Math.round(cfg.priceDcoin).toLocaleString('tr-TR') + ' D-Coin ile de alınabilir');
    out.push('');
    out.push('🚀 Anında teslimat · WhatsApp’tan hızlı sipariş');
    out.push('🛒 ' + cfg.purl);
    if (tags) { out.push(''); out.push(tags); }
    return out.join('\n');
  }

  return {
    FORMATS: FORMATS,
    render: render,
    resolveImage: resolveImage,
    buildCaption: buildCaption
  };
})();
