<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/_postlib.php';

/**
 * Toplu Sosyal Medya Post Paketi
 * Aktif ürünler için seçilen format(lar)da PNG üretir ve ZIP olarak indirir.
 * Filtre + sınır ile çalışır; tüm katalog tek seferde üretilmez (tarayıcı belleği).
 */
$data = dg_read_data();
$items = dg_enrich_store_items($data, dg_sort_newest($data['store_items'] ?? []));
$items = array_values(array_filter($items, static function (array $it): bool {
    return (int)($it['is_active'] ?? 0) === 1;
}));
$cfgs = array_map('dg_post_design', $items);
$totalActive = count($cfgs);

admin_head('Toplu Post Paketi');
?>
<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:16px">
  <div>
    <h1 style="font-size:22px;margin:0">📦 Toplu Sosyal Medya Post Paketi</h1>
    <div class="dg-muted" style="font-size:12px;margin-top:4px">
      <a href="store.php" style="color:inherit">← Mağaza yönetimi</a> ·
      <b><?= $totalActive ?></b> aktif ürün · Filtreleyip sınırlandırarak PNG paketini tek ZIP olarak indirin.
    </div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="dg-btn dg-btn-ghost" href="post.php?id=<?= (int)($cfgs[0]['id'] ?? 0) ?>">Tekil oluşturucu</a>
  </div>
</div>

<div class="dg-card" style="padding:18px;max-width:860px">
  <?php if (!$cfgs): ?>
    <div class="dg-muted">Aktif ürün yok. <a href="store.php">Mağaza yönetiminden</a> ürün ekleyin ya da aktifleştirin.</div>
  <?php else: ?>
    <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-end">
      <div>
        <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">Formatlar</div>
        <div style="display:flex;gap:14px;flex-wrap:wrap">
          <label class="dg-check"><input type="checkbox" class="fmt" value="kare" checked> <span>◻ Kare 1080×1080</span></label>
          <label class="dg-check"><input type="checkbox" class="fmt" value="yatay"> <span>▭ Yatay 1200×630</span></label>
          <label class="dg-check"><input type="checkbox" class="fmt" value="story"> <span>📱 Story 1080×1920</span></label>
        </div>
      </div>
      <div>
        <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">Ürün filtresi</div>
        <input type="search" id="fFilter" placeholder="Ürün adında ara (ör. Steam, Batman...)"
               style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:12px;padding:10px 12px;width:260px">
      </div>
      <div>
        <div class="dg-muted" style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px">Ürün sınırı</div>
        <input type="number" id="fLimit" value="100" min="1" max="300" step="1"
               style="background:var(--card2);color:var(--text);border:1px solid var(--line);border-radius:12px;padding:10px 12px;width:100px">
      </div>
      <button type="button" id="btnStart" class="dg-btn dg-btn-primary" style="min-width:200px">🚀 Üretimi başlat</button>
    </div>

    <div id="count" class="dg-muted" style="font-size:12px;margin-top:12px"></div>

    <div style="margin-top:10px">
      <div style="height:10px;background:var(--card2);border:1px solid var(--line);border-radius:99px;overflow:hidden">
        <div id="bar" style="height:100%;width:0;background:linear-gradient(90deg,#7c41cd,#b4e04f);transition:width .25s"></div>
      </div>
      <div id="status" class="dg-muted" style="font-size:12px;margin-top:8px">Hazır. Formatları seçip üretimi başlatın.</div>
    </div>

    <div id="log" style="margin-top:12px;max-height:220px;overflow:auto;background:var(--card2);border:1px solid var(--line);border-radius:12px;padding:10px;font:500 11px/1.8 ui-monospace,monospace;display:none"></div>
  <?php endif; ?>
</div>

<script src="post-render.js"></script>
<script>
(function () {
  'use strict';
  var cfgs = <?= json_encode($cfgs, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
  var running = false;
  if (!cfgs.length) { return; }

  function $(id) { return document.getElementById(id); }
  function log(msg) {
    var el = $('log');
    el.style.display = 'block';
    el.innerHTML += msg + '<br>';
    el.scrollTop = el.scrollHeight;
  }

  function selection() {
    var q = ($('fFilter').value || '').trim().toLocaleLowerCase('tr');
    var lim = parseInt($('fLimit').value, 10);
    if (isNaN(lim) || lim < 1) lim = 1;
    if (lim > 300) lim = 300;
    $('fLimit').value = lim;
    var out = [];
    for (var i = 0; i < cfgs.length && out.length < lim; i++) {
      if (!q || String(cfgs[i].name).toLocaleLowerCase('tr').indexOf(q) >= 0) out.push(cfgs[i]);
    }
    return out;
  }

  function refreshCount() {
    var sel = selection();
    var fmts = 0;
    document.querySelectorAll('.fmt').forEach(function (c) { if (c.checked) fmts++; });
    $('count').innerHTML = 'Seçilen: <b>' + sel.length + '</b> ürün × <b>' + fmts + '</b> format = <b>' +
      (sel.length * fmts) + '</b> PNG' +
      (sel.length * fmts > 200 ? ' ⚠ Bu kadar üretim birkaç dakika sürebilir.' : '');
  }
  $('fFilter').addEventListener('input', refreshCount);
  $('fLimit').addEventListener('input', refreshCount);
  document.querySelectorAll('.fmt').forEach(function (c) { c.addEventListener('change', refreshCount); });
  refreshCount();

  // ---- Bağımlılıksız ZIP (STORE, sıkıştırmasız — PNG zaten sıkışıklıdır) ----
  var crcTable = null;
  function crc32(u8) {
    if (!crcTable) {
      crcTable = new Uint32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        crcTable[n] = c >>> 0;
      }
    }
    var crc = 0xFFFFFFFF;
    for (var i = 0; i < u8.length; i++) crc = crcTable[(crc ^ u8[i]) & 0xFF] ^ (crc >>> 8);
    return (crc ^ 0xFFFFFFFF) >>> 0;
  }

  function u16(v) { return new Uint8Array([v & 255, (v >> 8) & 255]); }
  function u32(v) { return new Uint8Array([v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255]); }

  function makeZip(files) {
    var enc = new TextEncoder();
    var parts = [];
    var central = [];
    var offset = 0;
    var now = new Date();
    var dosTime = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xFFFF;
    var dosDate = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xFFFF;

    files.forEach(function (f) {
      var nameB = enc.encode(f.name);
      var crc = crc32(f.data);
      var size = f.data.length;
      parts.push(
        u32(0x04034b50), u16(20), u16(0x0800), u16(0), u16(dosTime), u16(dosDate),
        u32(crc), u32(size), u32(size), u16(nameB.length), u16(0),
        nameB, f.data
      );
      central.push({ nameB: nameB, crc: crc, size: size, offset: offset });
      offset += 30 + nameB.length + size;
    });

    var cdStart = offset;
    central.forEach(function (c) {
      parts.push(
        u32(0x02014b50), u16(20), u16(20), u16(0x0800), u16(0), u16(dosTime), u16(dosDate),
        u32(c.crc), u32(c.size), u32(c.size), u16(c.nameB.length), u16(0), u16(0), u16(0), u16(0),
        u32(0), u32(c.offset),
        c.nameB
      );
      offset += 46 + c.nameB.length;
    });
    var cdSize = offset - cdStart;
    parts.push(u32(0x06054b50), u16(0), u16(0), u16(central.length), u16(central.length), u32(cdSize), u32(cdStart), u16(0));
    return new Blob(parts, { type: 'application/zip' });
  }

  function safeName(s) {
    return String(s || 'urun')
      .toLowerCase()
      .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/ı/g, 'i').replace(/ş/g, 's').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ö/g, 'o').replace(/ç/g, 'c')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .substring(0, 48) || 'urun';
  }

  function toU8(blob) {
    return blob.arrayBuffer().then(function (buf) { return new Uint8Array(buf); });
  }

  $('btnStart').addEventListener('click', function () {
    if (running) return;
    var fmts = [];
    document.querySelectorAll('.fmt').forEach(function (c) { if (c.checked) fmts.push(c.value); });
    if (!fmts.length) { alert('En az bir format seçin.'); return; }
    if (!window.DGPost) { alert('Render kütüphanesi yüklenemedi.'); return; }

    var sel = selection();
    if (!sel.length) { alert('Filtreye uygun ürün yok.'); return; }
    if (sel.length * fmts.length > 300 && !confirm(sel.length * fmts.length + ' PNG üretilecek. Bu işlem birkaç dakika sürebilir. Devam edilsin mi?')) {
      return;
    }

    running = true;
    $('btnStart').disabled = true;
    $('log').innerHTML = '';
    var files = [];
    var total = sel.length * fmts.length;
    var done = 0;
    var errs = 0;

    function step(i) {
      if (i >= sel.length) {
        $('status').textContent = 'ZIP hazırlanıyor...';
        var blob = makeZip(files);
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        var d = new Date();
        var stamp = d.getFullYear() + ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2);
        a.download = 'dg-post-paketi-' + stamp + '.zip';
        document.body.appendChild(a);
        a.click();
        a.remove();
        setTimeout(function () { URL.revokeObjectURL(a.href); }, 8000);
        $('bar').style.width = '100%';
        $('status').innerHTML = '✅ Tamamlandı: <b>' + files.length + '</b> PNG paketlendi' +
          (errs ? ' · ' + errs + ' üründe görsel bulunamadı (glyph tasarımla üretildi)' : '') +
          ' · ZIP indirildi.';
        $('btnStart').disabled = false;
        running = false;
        return;
      }

      var cfg = sel[i];
      DGPost.resolveImage(cfg).then(function (img) {
        var inner = function (j) {
          if (j >= fmts.length) { step(i + 1); return; }
          var f = fmts[j];
          try {
            var cv = document.createElement('canvas');
            DGPost.render(cv, cfg, f, {
              title: cfg.name,
              sub: cfg.desc,
              showPrice: true,
              showDesc: true
            }, img);
            cv.toBlob(function (blob) {
              toU8(blob).then(function (u8) {
                files.push({
                  name: 'posts/' + ('000' + cfg.id).slice(-4) + '-' + safeName(cfg.name) + '-' + f + '.png',
                  data: u8
                });
                done++;
                if (!img) errs++;
                $('bar').style.width = Math.round((done / total) * 100) + '%';
                $('status').textContent = done + ' / ' + total + ' — ' + cfg.name + ' (' + f + ')';
                log('✓ ' + cfg.name + ' — ' + f);
                inner(j + 1);
              });
            }, 'image/png');
          } catch (e) {
            errs++;
            done++;
            log('✗ ' + cfg.name + ' — ' + f + ' (' + (e && e.message ? e.message : 'hata') + ')');
            inner(j + 1);
          }
        };
        inner(0);
      });
    }
    step(0);
  });
})();
</script>
<?php admin_foot(); ?>
