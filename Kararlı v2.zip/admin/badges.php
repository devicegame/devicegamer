<?php
declare(strict_types=1);
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_layout.php';
require_once __DIR__ . '/../lib/social.php';
social_ensure_storage();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify((string)($_POST['csrf'] ?? ''))) {
        flash_error_set('Güvenlik doğrulaması başarısız.');
    } else {
        try {
            $action = (string)($_POST['action'] ?? '');
            $id = (string)($_POST['badge_id'] ?? '');
            $userId = (int)($_POST['user_id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            if ($action === 'assign' || $action === 'revoke') {
                if (!$userId || !dg_find_user_by_id($userId)) throw new RuntimeException('Kullanıcı bulunamadı.');
            }
            $msg = social_with_lock(function () use ($action, $id, $userId, $name): string {
                $data = social_badge_data();
                if ($action === 'create') {
                    $name = social_clean_text($name, 48);
                    if ($name === '') throw new RuntimeException('Rozet adı boş olamaz.');
                    foreach ($data['definitions'] as $badge) {
                        if (social_fold((string)($badge['name'] ?? '')) === social_fold($name) && empty($badge['archived'])) throw new RuntimeException('Bu isimde aktif rozet zaten var.');
                    }
                    $data['definitions'][] = ['id' => bin2hex(random_bytes(12)), 'name' => $name, 'archived' => false, 'created_at' => time()];
                    $message = 'Rozet oluşturuldu.';
                } else {
                    $index = null;
                    foreach ($data['definitions'] as $i => $badge) if ((string)($badge['id'] ?? '') === $id) { $index = $i; break; }
                    if ($index === null) throw new RuntimeException('Rozet bulunamadı.');
                    if ($action === 'archive') {
                        $data['definitions'][$index]['archived'] = true;
                        $message = 'Rozet arşivlendi; mevcut sahiplerinde görünmeye devam eder.';
                    } elseif ($action === 'assign' || $action === 'revoke') {
                        if ($action === 'assign' && !empty($data['definitions'][$index]['archived'])) throw new RuntimeException('Arşivlenmiş rozet yeni kişilere verilemez.');
                        $key = (string)$userId;
                        $assigned = array_values(array_filter((array)($data['assignments'][$key] ?? []), static fn($item): bool => (string)$item !== $id));
                        if ($action === 'assign') $assigned[] = $id;
                        $data['assignments'][$key] = $assigned;
                        $message = $action === 'assign' ? 'Rozet kullanıcıya verildi.' : 'Rozet kullanıcıdan kaldırıldı.';
                    } else throw new RuntimeException('Geçersiz işlem.');
                }
                social_write_json_atomic(social_storage_dir() . '/admin-badges.json', $data);
                return $message;
            });
            flash_set($msg);
        } catch (Throwable $e) { flash_error_set($e->getMessage()); }
    }
    header('Location: badges.php', true, 303); exit;
}
$data = social_badge_data();
$users = dg_all('users');
admin_head('Rozet yönetimi');
?>
<h1>🏅 Rozet yönetimi</h1>
<p class="dg-muted">Başarı rozetlerini yalnızca yöneticiler oluşturup kullanıcılara verebilir. Arşivlenen rozetler mevcut sahiplerinde kalır.</p>
<div class="dg-card" style="margin:20px 0"><div class="dg-card-body">
<form method="post" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap"><?= csrf_field() ?>
<input type="hidden" name="action" value="create"><label class="dg-field"><span>Yeni rozet adı</span><input name="name" maxlength="48" required></label><button class="dg-btn dg-btn-primary">Rozet oluştur</button></form>
</div></div>
<div class="dg-card"><div class="dg-card-body">
<h2>Rozet ver veya kaldır</h2>
<form method="post" style="display:flex;gap:10px;align-items:end;flex-wrap:wrap"><?= csrf_field() ?>
<label class="dg-field"><span>Kullanıcı</span><select name="user_id" required><?php foreach ($users as $row): ?><option value="<?= (int)$row['id'] ?>"><?= e($row['username']) ?></option><?php endforeach; ?></select></label>
<label class="dg-field"><span>Rozet</span><select name="badge_id" required><?php foreach ($data['definitions'] as $badge): ?><option value="<?= e($badge['id']) ?>"><?= e($badge['name']) ?><?= !empty($badge['archived']) ? ' (arşiv)' : '' ?></option><?php endforeach; ?></select></label>
<button name="action" value="assign" class="dg-btn dg-btn-primary">Rozet ver</button><button name="action" value="revoke" class="dg-btn dg-btn-ghost">Kullanıcıdan kaldır</button>
</form></div></div>
<div class="dg-card" style="margin-top:20px"><div class="dg-card-body"><h2>Tanımlı rozetler</h2>
<?php if (!$data['definitions']): ?><p>Henüz rozet oluşturulmadı.</p><?php endif; ?>
<?php foreach ($data['definitions'] as $badge): ?><div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:10px 0"><strong><?= e($badge['name']) ?></strong>
<?php if (!empty($badge['archived'])): ?><span class="dg-muted">Arşivlendi</span><?php else: ?><form method="post" onsubmit="return confirm('Rozet arşivlensin mi? Mevcut sahiplerinde kalır.')"><?= csrf_field() ?><input type="hidden" name="action" value="archive"><input type="hidden" name="badge_id" value="<?= e($badge['id']) ?>"><button class="dg-btn dg-btn-ghost dg-btn-sm">Arşivle</button></form><?php endif; ?></div><?php endforeach; ?>
</div></div>
<?php admin_foot(); ?>
