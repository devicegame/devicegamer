<?php
require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/_layout.php';

/** Sosyal medya paylaşımı için görsel proxy'si (yalnızca yöneticiler). */
$url = trim((string)($_GET['url'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] !== 'GET' || !preg_match('#^https?://#i', $url)) {
    http_response_code(400);
    exit('Geçersiz istek');
}

$ctx = stream_context_create([
    'http' => ['timeout' => 8, 'follow_location' => 1, 'max_redirects' => 3,
               'header' => "User-Agent: DG-PostCreator/1.0\r\nAccept: image/*\r\n"],
    'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
]);
$data = @file_get_contents($url, false, $ctx);
if ($data === false || $data === '' || strlen($data) > 8 * 1024 * 1024) {
    http_response_code(502);
    exit('Görsel getirilemedi');
}

$mime = '';
foreach ($http_response_header ?? [] as $h) {
    if (preg_match('#^content-type:\s*(image/[\w.+-]+)#i', $h, $m)) {
        $mime = strtolower($m[1]);
        break;
    }
}

// Sihirli bayt kontrolü: yalnızca gerçek görsel verisini geçir.
$sig = substr($data, 0, 12);
$magic = null;
if (substr($sig, 0, 8) === "\x89PNG\r\n\x1a\n") $magic = 'image/png';
elseif (substr($sig, 0, 3) === "\xff\xd8\xff") $magic = 'image/jpeg';
elseif (substr($sig, 0, 6) === 'GIF87a' || substr($sig, 0, 6) === 'GIF89a') $magic = 'image/gif';
elseif (substr($sig, 0, 4) === 'RIFF' && substr($sig, 8, 4) === 'WEBP') $magic = 'image/webp';
elseif (substr($sig, 0, 4) === "\x00\x00\x01\x00") $magic = 'image/x-icon';
if ($magic === null) {
    http_response_code(415);
    exit('Bu kaynak görsel değil');
}
$mime = $magic;

header('Content-Type: ' . $mime);
header('Cache-Control: private, max-age=86400');
header('Content-Length: ' . strlen($data));
echo $data;
