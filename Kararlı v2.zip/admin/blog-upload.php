<?php
declare(strict_types=1);

require_once __DIR__ . '/_auth.php';
require_once __DIR__ . '/../lib/shop.php';
require_once __DIR__ . '/../lib/admin.php';

function dg_blog_upload_json(bool $ok, array $payload = [], int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');
    echo json_encode(array_merge(['ok' => $ok], $payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    dg_blog_upload_json(false, ['error' => 'Yalnızca POST isteği kabul edilir.'], 405);
}

if (!csrf_verify((string)($_POST['csrf'] ?? ''))) {
    dg_blog_upload_json(false, ['error' => 'CSRF doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.'], 419);
}

$kind = (string)($_POST['kind'] ?? 'inline');
$kind = $kind === 'cover' ? 'cover' : 'inline';
$file = isset($_FILES['image']) && is_array($_FILES['image']) ? $_FILES['image'] : [];

try {
    $result = admin_store_blog_image($file, $kind);
} catch (Throwable $exception) {
    error_log('[admin blog upload] ' . $exception->getMessage());
    dg_blog_upload_json(false, ['error' => 'Görsel yüklenirken sunucu hatası oluştu.'], 500);
}

if (($result['path'] ?? '') === '') {
    dg_blog_upload_json(false, [
        'error' => ($result['error'] ?? '') !== '' ? $result['error'] : 'Yüklenecek görsel seçilmedi.',
    ], 422);
}

dg_blog_upload_json(true, [
    'path' => $result['path'],
    'url' => '/' . ltrim((string)$result['path'], '/'),
    'width' => (int)($result['width'] ?? 0),
    'height' => (int)($result['height'] ?? 0),
]);
