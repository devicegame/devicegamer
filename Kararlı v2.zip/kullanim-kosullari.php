<?php
$page_title = 'Kullanım Koşulları';
$page_canonical = 'kullanim-kosullari.php';
$page_og_type = 'article';
$page_og_title = 'Kullanım Koşulları';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">Kullanım Koşulları</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Siteyi kullanırken geçerli kurallar.</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                devicegame.com internet sitesi ile bağlı alt alan adlarını (birlikte "Site") kullanan
                herkes, aşağıdaki koşulları kabul etmiş sayılır. Güncelleme tarihi: 29 Ekim 2026.
            </p>

            <div class="story-block">
                <h3>Kapsam</h3>
                <p>
                    İşbu koşullar; mağaza, blog, DG Social topluluk alanı ve stüdyo sayfaları dâhil
                    Site'nin tüm bölümlerinin kullanımına ilişkindir. Alışveriş süreçleri için ayrıca
                    <a class="text-link" href="on-bilgilendirme.php">Ön Bilgilendirme Formu</a> ve
                    <a class="text-link" href="mesafeli-satis.php">Mesafeli Satış Sözleşmesi</a>,
                    kişisel veriler için <a class="text-link" href="gizlilik.php">Gizlilik Politikası</a> ve
                    <a class="text-link" href="kvkk.php">KVKK Aydınlatma Metni</a> geçerlidir.
                </p>
            </div>

            <div class="story-block">
                <h3>Hesap ve üyelik</h3>
                <ul>
                    <li>DG Social bölümlerini kullanabilmek için hesap oluşturabilirsiniz. Kayıt sırasında verdiğiniz bilgilerin doğru ve güncel olmasından siz sorumlusunuz.</li>
                    <li>Şifrenizi gizli tutun; hesabınız üzerinden yapılan işlemlerden siz sorumlusunuz.</li>
                    <li>Hesap oluşturarak en az 18 yaşında olduğunuzu ya da hizmeti veli/onay sahibi gözetiminde kullandığınızı beyan edersiniz.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Kullanıcı içeriği ve davranış</h3>
                <p>
                    Site üzerinde paylaştığınız yorum, mesaj, gönderi ve diğer içeriklerden siz
                    sorumlusunuz. Aşağıdaki davranışlar yasaktır:
                </p>
                <ul>
                    <li>Yasa dışı, hakaret içeren, tehdit edici, ayrımcı veya müstehcen içerik paylaşmak.</li>
                    <li>Telif hakkı, ticari marka veya kişilik haklarını ihlal etmek.</li>
                    <li>Spam, reklam bombardımanı veya yanıltıcı bilgi yaymak.</li>
                    <li>Site'nin işleyişine müdahale etmek, otomatik araçlarla veri toplamak veya güvenlik tedbirlerini aşmaya çalışmak.</li>
                    <li>Başkalarının hesaplarına izinsiz erişmek.</li>
                </ul>
                <p>
                    Topluluk alanına özel ayrıntılar için
                    <a class="text-link" href="sosyal/kurallar.php">Topluluk Kuralları</a>'nı inceleyin.
                    Kullanım koşullarına aykırı içerikler silinebilir; ilgili hesaplar askıya alınabilir
                    veya kapatılabilir.
                </p>
            </div>

            <div class="story-block">
                <h3>D-Coin</h3>
                <p>
                    D-Coin, Site içerisinde kullanılan sanal bir alışveriş birimidir. Gerçek para birimi
                    değildir; devredilemez, transfer edilemez ve Site dışında takas edilemez. D-Coin
                    kazanım ve kullanım kuralları zaman zaman güncellenebilir; kötüye kullanım tespit
                    edildiğinde ilgili bakiye iptal edilebilir. Konuyla ilgili sorularınız için destek
                    ekibimizle iletişime geçin.
                </p>
            </div>

            <div class="story-block">
                <h3>Fikri mülkiyet</h3>
                <ul>
                    <li>
                        Site'nin tasarımı, logosu, metinleri, görselleri, yazılımı ve diğer tüm içeriği
                        <strong><?php echo e($company_name); ?></strong>'e aittir veya lisans altında kullanılır;
                        önceden yazılı izin alınmadan çoğaltılamaz, dağıtılamaz veya ticari amaçla kullanılamaz.
                    </li>
                    <li>
                        Sattığımız ürünler, ilgili oyun ve platformların (Steam, Epic Games vb.) markaları
                        kendi sahiplerine aittir; bu platformların resmî ortaklığı/desteği bulunmadığını
                        belirtiriz.
                    </li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Sorumluluğun sınırı</h3>
                <ul>
                    <li>Site içeriği "olduğu gibi" sunulur; kesintisiz ve hatasız çalışacağına dair garanti verilmez.</li>
                    <li>Dijital ürünlerin teslimi, aktivasyonu ve kullanımı, ilgili oyun/platformun kendi kullanım koşullarına tabidir.</li>
                    <li>Üçüncü taraf sitelere verilen bağlantıların içeriğinden sorumlu değiliz.</li>
                    <li>Yasaların izin verdiği ölçüde, doğrudan veya dolaylı zararlardan doğan toplam sorumluluğumuz ilgili siparişin bedelini aşamaz.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Değişiklikler</h3>
                <p>
                    İşbu koşullar önceden haber verilmeksizin güncellenebilir. Güncel sürüm her zaman bu
                    sayfada yayınlanır; Site'yi kullanmaya devam etmeniz güncel koşulları kabul ettiğiniz
                    anlamına gelir.
                </p>
            </div>

            <div class="story-block">
                <h3>Uyuşmazlıkların çözümü</h3>
                <p>
                    İşbu koşullardan doğabilecek uyuşmazlıklarda Türk hukuku uygulanır. Tüketici
                    işlemlerinde ilgili mevzuatta belirtilen parasal sınırlar dâhilinde Tüketici Hakem
                    Heyetleri ve Tüketici Mahkemeleri; diğer uyuşmazlıklarda ise İzmir (Torbalı)
                    Mahkemeleri ve İcra Daireleri yetkilidir.
                </p>
            </div>

            <div class="story-block">
                <h3>İletişim</h3>
                <p>
                    Sorularınız için:
                    <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a> ·
                    <?php echo e($hq_address); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
