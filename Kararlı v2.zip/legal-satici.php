<?php
/** Yasal sayfalarda tekrar eden satıcı bilgi kutusu. */
$legal_unvan         = $legal_unvan ?? $company_name;
$legal_telefon       = $legal_telefon ?? '+90 551 957 83 50';
$legal_vergi_dairesi = $legal_vergi_dairesi ?? '';
$legal_vergi_no      = $legal_vergi_no ?? '';
$legal_mersis        = $legal_mersis ?? '';
?>
<div class="legal-box">
    <h3>Satıcı bilgileri</h3>
    <div class="legal-contact">
        <div>
            <b>Unvan</b>
            <span><?php echo e($legal_unvan); ?></span>
        </div>
        <div>
            <b>Adres</b>
            <span><?php echo e($hq_address); ?></span>
        </div>
        <div>
            <b>E-posta</b>
            <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
        </div>
        <div>
            <b>Telefon</b>
            <a href="tel:<?php echo e(preg_replace('/[^0-9+]/', '', $legal_telefon)); ?>"><?php echo e($legal_telefon); ?></a>
        </div>
        <?php if ($legal_vergi_dairesi !== '' || $legal_vergi_no !== ''): ?>
        <div>
            <b>Vergi bilgileri</b>
            <span><?php echo e(trim($legal_vergi_dairesi . ($legal_vergi_no !== '' ? ' · ' . $legal_vergi_no : ''))); ?></span>
        </div>
        <?php endif; ?>
        <?php if ($legal_mersis !== ''): ?>
        <div>
            <b>MERSİS No</b>
            <span><?php echo e($legal_mersis); ?></span>
        </div>
        <?php endif; ?>
    </div>
</div>
