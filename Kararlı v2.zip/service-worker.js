const CACHE = 'devicegame-offline-v1';
const OFFLINE = '/offline.html';
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll([OFFLINE])).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('devicegame-offline-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || request.mode !== 'navigate' || new URL(request.url).origin !== self.location.origin) return;
  // Kişisel sayfaları, oturumları ve API yanıtlarını önbelleğe almayız.
  event.respondWith(fetch(request).catch(async () => (await caches.match(OFFLINE)) || new Response('Bağlantı yok.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=UTF-8' } })));
});
