<?php
$page_title = 'Gizlilik Politikası';
$page_canonical = 'gizlilik.php';
$page_og_type = 'article';
$page_og_title = 'Gizlilik Politikası';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">Gizlilik Politikası</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Verilerinize nasıl yaklaştığımız.</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                Bu politika; Site kullanımınız sırasında toplanan bilgilerin nasıl kullanıldığını ve
                korunduğunu özetler. Kişisel verilere ilişkin resmî aydınlatma metnimiz için
                <a class="text-link" href="kvkk.php">KVKK Aydınlatma Metni</a>'ni inceleyin.
                Güncelleme tarihi: 30 Ekim 2026.
            </p>

            <div class="story-block">
                <h3>Topladığımız bilgiler</h3>
                <ul>
                    <li><strong>Teknik bilgiler:</strong> IP adresi, tarayıcı ve cihaz türü, oturum kayıtları.</li>
                    <li><strong>Hesap ve topluluk bilgileri:</strong> kullanıcı adı, e-posta adresi, profil bilgileri, topluluk etkinlikleri ve bildirim tercihleri.</li>
                    <li><strong>Sipariş bilgileri:</strong> ad soyad, e-posta, sipariş notu, satın alınan ürünler ve işlem kayıtları.</li>
                    <li><strong>İletişim içerikleri:</strong> e-posta veya WhatsApp üzerinden bize ilettiğiniz mesajlar.</li>
                    <li><strong>Çerezler:</strong> oturum yönetimi için zorunlu teknik çerezler (ör. PHPSESSID).</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Bilgileri nasıl kullanıyoruz</h3>
                <ul>
                    <li>Siparişlerin hazırlanması, teslimi, iade ve değişim süreçlerinin yürütülmesi.</li>
                    <li>Müşteri desteği ve iletişim taleplerinin karşılanması.</li>
                    <li>Sipariş ve hesapla ilgili işlem bildirimlerinin; tercihlerinize göre sosyal bildirimlerin e-posta ile iletilmesi.</li>
                    <li>Site güvenliğinin sağlanması ve kötüye kullanımın önlenmesi.</li>
                    <li>Vergi, ticaret ve tüketici mevzuatından doğan yasal yükümlülüklerin yerine getirilmesi.</li>
                    <li>Yalnızca açık rıza verilmesi hâlinde kampanya ve duyuruların iletilmesi.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>E-posta bildirimleri</h3>
                <p>Sipariş özeti ve sipariş durumu gibi hizmet bildirimleri, sağladığınız e-posta adresine gönderilebilir. DG Social bildirimleri de e-postayla özetlenebilir; sosyal e-posta bildirimlerini profil ayarlarınızdan kapatabilirsiniz. Özel mesaj içerikleri ve ürün anahtarları bildirim e-postalarına eklenmez. Bu bildirimler pazarlama iletilerinden ayrıdır.</p>
            </div>

            <div class="story-block">
                <h3>Bilgilerin paylaşımı</h3>
                <p>
                    Bilgileriniz; barındırma (hosting), e-posta iletimi ve teknik hizmet sağlayıcılarımız, ödeme
                    süreçlerinde bankalar, fiziksel ürün teslimatlarında kargo firmaları ve yasal
                    zorunluluk hâllerinde yetkili kamu kurumları ile gerekli ölçüde paylaşılır.
                    <strong>Açık rızanız olmadan</strong> pazarlama amaçlı olarak üçüncü kişilerle
                    paylaşılmaz veya satılmaz.
                </p>
            </div>

            <div class="story-block">
                <h3>Çerezler</h3>
                <p>
                    Oturum ve sepet süreçleri için teknik çerezler kullanılır. Sosyal taslaklar ve kaydırma konumu gibi tercihler tarayıcının yerel veya oturum depolamasında saklanabilir. Çerezleri ve bu verileri tarayıcı ayarlarınızdan silebilir veya engelleyebilirsiniz; bazı özellikler bu durumda çalışmayabilir. Üçüncü taraf görsel veya video içerikleri yüklendiğinde ilgili sağlayıcının uygulamaları da geçerli olabilir.
                </p>
            </div>

            <div class="story-block">
                <h3>Güvenlik</h3>
                <p>
                    Verilerinizin korunması için makul teknik ve idari tedbirler (HTTPS şifreleme, erişim
                    kısıtlamaları, kayıt tutma) uygularız. Ancak hiçbir internet iletim yönteminin
                    %100 güvenli olduğunu garanti edemeyiz.
                </p>
            </div>

            <div class="story-block">
                <h3>Saklama süreleri</h3>
                <p>
                    Veriler, ilgili işlemin amacı ve yürürlükteki yasal saklama yükümlülükleri için gerekli süre boyunca saklanır. Süreler veri türüne ve yürürlükteki mevzuata göre belirlenir. Pazarlama izni verilmişse geri alınması mümkündür.
                </p>
            </div>

            <div class="story-block">
                <h3>Çocukların gizliliği</h3>
                <p>
                    Hizmetlerimiz 18 yaş ve üzeri kullanıcılar için tasarlanmıştır. 18 yaş altındaki
                    kullanıcıların hizmetleri veli/gözetim onayıyla kullanması beklenir; bilerek çocuk
                    verisi toplama amacımız yoktur.
                </p>
            </div>

            <div class="story-block">
                <h3>Bağlantılı servisler</h3>
                <p>
                    WhatsApp üzerinden yürüttüğümüz iletişim ve satış süreçlerinde ilgili servisin kendi
                    gizlilik politikası geçerlidir. Aynı şekilde, satın alınan oyun ve platformların
                    (Steam, Epic Games vb.) kendi veri uygulamalarından bu platformlar sorumludur.
                </p>
            </div>

            <div class="story-block">
                <h3>Haklarınız</h3>
                <p>
                    Verilerinizle ilgili erişim, düzeltme, silme ve işlemeyi sınırlandırma talepleriniz için
                    <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                    adresine yazabilirsiniz. Ticari iletilerde dilediğiniz zaman ret hakkınızı
                    kullanabilirsiniz. Ayrıntılar:
                    <a class="text-link" href="kvkk.php">KVKK Aydınlatma Metni</a>.
                </p>
            </div>

            <div class="story-block">
                <h3>Politika değişiklikleri</h3>
                <p>
                    Bu politika zaman zaman güncellenebilir; güncel sürüm her zaman bu sayfada yayınlanır.
                    Önemli değişikliklerde Site üzerinden duyuru yapılabilir.
                </p>
            </div>

            <div class="story-block">
                <h3>İletişim</h3>
                <?php include 'legal-satici.php'; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
