<?php
/** Yasal sayfalar arası ortak menü. */
$legal_pages = [
    'on-bilgilendirme.php' => 'Ön Bilgilendirme',
    'mesafeli-satis.php'   => 'Mesafeli Satış Sözleşmesi',
    'iade-kosullari.php'   => 'İade & Değişim',
    'kullanim-kosullari.php' => 'Kullanım Koşulları',
    'gizlilik.php'         => 'Gizlilik',
    'kvkk.php'             => 'KVKK',
];
$legal_current = basename((string)($_SERVER['PHP_SELF'] ?? ''));
?>
<nav class="legal-nav" aria-label="Yasal sayfalar">
    <?php foreach ($legal_pages as $legal_file => $legal_label): ?>
        <a href="<?php echo e($legal_file); ?>"<?php echo $legal_file === $legal_current ? ' class="is-active" aria-current="page"' : ''; ?>><?php echo e($legal_label); ?></a>
    <?php endforeach; ?>
</nav>
