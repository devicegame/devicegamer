<?php
/** Device Game işlem bildirimleri. Kuyruk web kökünün dışında tutulur. */
if (!defined('DG_MAIL_HELPERS')) {
    define('DG_MAIL_HELPERS', true);
    define('DG_MAIL_FROM', 'bildirim@devicegame.com');
    define('DG_MAIL_BASE_URL', 'https://devicegame.com');

    function dg_mail_root(): string
    {
        return dirname(__DIR__, 2) . '/.devicegame-mail';
    }

    function dg_mail_prepare(): bool
    {
        $root = dg_mail_root();
        foreach ([$root, $root . '/queue', $root . '/working', $root . '/state'] as $dir) {
            if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) return false;
            @chmod($dir, 0700);
        }
        return is_writable($root . '/queue') && is_writable($root . '/working') && is_writable($root . '/state');
    }

    function dg_mail_valid_address(string $address): bool
    {
        return strlen($address) <= 254 && !preg_match('/[\r\n]/', $address)
            && filter_var($address, FILTER_VALIDATE_EMAIL) !== false;
    }

    /** İstismar durumunda bir kaynaktan saatte en fazla 15 sipariş e-postası kuyruğa alınır. */
    function dg_mail_allow_order_enqueue(): bool
    {
        if (!dg_mail_prepare()) return false;
        $remote = (string)($_SERVER['REMOTE_ADDR'] ?? 'cli');
        $name = hash('sha256', $remote . '|' . gmdate('Y-m-d-H'));
        $path = dg_mail_root() . '/state/enqueue-' . $name . '.txt';
        $f = @fopen($path, 'c+');
        if (!$f) return false;
        try {
            if (!flock($f, LOCK_EX)) return false;
            $value = (int)stream_get_contents($f);
            if ($value >= 15) return false;
            rewind($f); ftruncate($f, 0); fwrite($f, (string)($value + 1)); fflush($f);
            @chmod($path, 0600);
            return true;
        } finally {
            @flock($f, LOCK_UN); fclose($f);
        }
    }

    /** Her iş ayrı dosyadır; aynı kullanıcı için sosyal bildirimler birlikte özetlenir. */
    function dg_mail_enqueue(array $job, string $dedupe = ''): bool
    {
        try {
            if (!dg_mail_prepare()) return false;
            $id = $dedupe !== '' ? $dedupe : 'job-' . bin2hex(random_bytes(12));
            if (!preg_match('/^[a-z0-9-]{1,80}$/', $id)) return false;
            $queue = dg_mail_root() . '/queue';
            $target = $queue . '/' . $id . '.json';
            if ($dedupe !== '' && is_file($target)) return true;
            $job['created_at'] = time();
            $job['next_attempt'] = time();
            $job['attempts'] = 0;
            $json = json_encode($job, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false) return false;
            $tmp = $queue . '/.' . bin2hex(random_bytes(12)) . '.tmp';
            if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
            @chmod($tmp, 0600);
            if ($dedupe !== '') {
                // Hard-link pek çok paylaşımlı sunucuda kapalıdır. Kilit + atomik
                // rename, kuyruk işçisinin yarım JSON görmesini de önler.
                $lockPath = dg_mail_root() . '/state/dedupe-' . $id . '.lock';
                $dedupeLock = @fopen($lockPath, 'c+');
                if (!$dedupeLock) { @unlink($tmp); return false; }
                try {
                    if (!@flock($dedupeLock, LOCK_EX)) { @unlink($tmp); return false; }
                    @touch($lockPath); @chmod($lockPath, 0600);
                    clearstatcache(true, $target);
                    $ok = is_file($target) || @rename($tmp, $target);
                    @unlink($tmp);
                    return $ok;
                } finally {
                    @flock($dedupeLock, LOCK_UN); fclose($dedupeLock);
                }
            }
            if (!@rename($tmp, $target)) { @unlink($tmp); return false; }
            return true;
        } catch (Throwable $e) {
            error_log('[DG mail] Bildirim kuyruğa alınamadı.');
            return false;
        }
    }

    function dg_mail_queue_social(int $userId, bool $directMessage = false): bool
    {
        if ($userId <= 0) return false;
        $type = $directMessage ? 'social_dm' : 'social';
        $key = $directMessage ? 'dm-' : 'social-';
        return dg_mail_enqueue(['type' => $type, 'user_id' => $userId], $key . $userId);
    }

    function dg_mail_queue_order(string $to, string $orderId, string $kind, string $status = ''): bool
    {
        $to = trim($to);
        if (!dg_mail_valid_address($to) || !in_array($kind, ['order_new', 'order_status', 'purchase'], true)) return false;
        if (!preg_match('/^[A-Za-z0-9-]{1,48}$/', $orderId)) return false;
        if ($kind === 'order_new' && !dg_mail_allow_order_enqueue()) return false;
        return dg_mail_enqueue(['type' => $kind, 'to' => $to, 'order_id' => $orderId, 'status' => $status]);
    }

    /** Kullanıcıya özel içerik, DM metni veya ürün anahtarı e-postaya eklenmez. */
    function dg_mail_resolve_job(array $job): ?array
    {
        $type = (string)($job['type'] ?? '');
        $to = trim((string)($job['to'] ?? ''));
        $subject = '';
        $body = '';
        if ($type === 'social' || $type === 'social_dm') {
            $uid = (int)($job['user_id'] ?? 0);
            if ($uid <= 0 || !function_exists('dg_find_user_by_id')) return null;
            $user = dg_find_user_by_id($uid);
            if (!$user || !empty($user['is_banned'])) return null;
            $profile = function_exists('social_get_profile') ? social_get_profile($uid, $user) : null;
            $prefs = function_exists('social_notification_prefs') ? social_notification_prefs(is_array($profile) ? $profile : []) : [];
            if (array_key_exists('email', $prefs) && empty($prefs['email'])) return null;
            if ($type === 'social_dm' && array_key_exists('messages', $prefs) && empty($prefs['messages'])) return null;
            $to = trim((string)($user['email'] ?? ''));
            if ($type === 'social_dm') {
                $subject = 'DG Social’da yeni özel mesajın var';
                $body = "Merhaba,\n\nDG Social’da yeni özel mesajın var. Mesajlarını görmek için:\n"
                    . DG_MAIL_BASE_URL . "/sosyal/mesajlar.php\n\n"
                    . "Gizliliğin için mesaj içeriği bu e-postaya eklenmez. Sosyal e-posta bildirimlerini profil ayarlarından kapatabilirsin.\n";
            } else {
                $subject = 'DG Social’da yeni bildirimin var';
                $body = "Merhaba,\n\nDG Social’da yeni bildirimin var. Yorum, yanıt, takip veya mesaj bildirimlerini görmek için:\n"
                    . DG_MAIL_BASE_URL . "/sosyal/bildirimler.php\n\n"
                    . "Gizliliğin için özel mesajların içeriği bu e-postaya eklenmez. Sosyal e-posta bildirimlerini profil ayarlarından kapatabilirsin.\n";
            }
        } elseif ($type === 'order_new') {
            $subject = 'Device Game sipariş özetin hazır';
            $body = "Merhaba,\n\nSipariş özetin oluşturuldu. Sipariş kodun: " . (string)($job['order_id'] ?? '') . "\n"
                . "Siparişin tamamlanması için açılan WhatsApp mesajını göndermen ve ödeme adımlarını takip etmen gerekir. Bu e-posta ödeme onayı değildir.\n";
        } elseif ($type === 'order_status') {
            $labels = ['new' => 'Yeni', 'preparing' => 'Hazırlanıyor', 'done' => 'Tamamlandı', 'cancelled' => 'İptal edildi'];
            $status = (string)($job['status'] ?? '');
            if (!isset($labels[$status])) return null;
            // Kuyrukta beklerken durum yeniden değişmişse eski bilgiyi gönderme.
            $statusFile = __DIR__ . '/../storage/order-status.json';
            $current = is_file($statusFile) ? json_decode((string)@file_get_contents($statusFile), true) : [];
            $orderId = (string)($job['order_id'] ?? '');
            if (!is_array($current) || (string)($current[$orderId] ?? 'new') !== $status) return null;
            $subject = 'Device Game sipariş durumun güncellendi';
            $body = "Merhaba,\n\n" . (string)($job['order_id'] ?? '') . " numaralı siparişinin durumu: " . $labels[$status] . ".\n"
                . "Soruların için sitemizdeki WhatsApp destek bağlantısını kullanabilirsin.\n";
        } elseif ($type === 'purchase') {
            $subject = 'Device Game satın alma kaydın';
            $body = "Merhaba,\n\nSatın alma kaydın oluşturuldu. Sipariş kodun: " . (string)($job['order_id'] ?? '') . "\n"
                . "Güvenliğin için ürün anahtarı bu e-postada yer almaz. Teslimat ayrıntılarını hesabından veya destek ekibinden öğrenebilirsin.\n";
        } elseif ($type === 'price_drop') {
            $uid = (int)($job['user_id'] ?? 0);
            $user = $uid > 0 && function_exists('dg_find_user_by_id') ? dg_find_user_by_id($uid) : null;
            $slug = (string)($job['slug'] ?? '');
            if (!$user || !empty($user['is_banned']) || $slug === '') return null;
            $to = (string)($user['email'] ?? '');
            $subject = 'Favori ürününün fiyatı düştü';
            $body = "Merhaba,\n\n" . (string)($job['name'] ?? 'Favori ürünün') . " fiyatı " . (int)($job['old'] ?? 0) . " TL’den " . (int)($job['new'] ?? 0) . " TL’ye düştü.\n" . DG_MAIL_BASE_URL . '/product.php?slug=' . rawurlencode($slug) . "\n";
        } elseif ($type === 'test') {
            $subject = 'Device Game bildirim sistemi test mesajı';
            $body = "Merhaba,\n\nBu ileti Device Game e-posta bildirim sisteminin testidir. Gerçek bir sipariş oluşturulmamıştır.\n";
        } else {
            return null;
        }
        if (!dg_mail_valid_address($to)) return null;
        $body .= "\nBu otomatik bilgilendirme adresine yanıt vermek yerine sitemizdeki WhatsApp destek bağlantısını kullanabilirsin.\n";
        $body .= "\nDevice Game\n" . DG_MAIL_BASE_URL . "/\n";
        return ['to' => $to, 'subject' => $subject, 'body' => $body, 'type' => $type,
            'user_id' => (int)($job['user_id'] ?? 0)];
    }

    /** Yerel MTA ile SMTP; paylaşımlı sunucularda PHP mail() kapalı olabilir. */
    function dg_mail_smtp_reply($socket): int
    {
        for ($i = 0; $i < 100; $i++) {
            $line = @fgets($socket, 4096);
            if (!is_string($line) || !preg_match('/^([0-9]{3})([ -])/', $line, $m)) return 0;
            if ($m[2] === ' ') return (int)$m[1];
        }
        return 0;
    }

    function dg_mail_smtp_write($socket, string $text): bool
    {
        $length = strlen($text); $offset = 0;
        while ($offset < $length) {
            $wrote = @fwrite($socket, substr($text, $offset));
            if (!is_int($wrote) || $wrote <= 0) return false;
            $offset += $wrote;
        }
        return true;
    }

    function dg_mail_send_local_smtp(array $message, string $subject): bool
    {
        if (!function_exists('stream_socket_client') || !dg_mail_valid_address((string)$message['to'])) return false;
        $socket = @stream_socket_client('tcp://127.0.0.1:25', $errorNo, $errorText, 5);
        if (!$socket) return false;
        @stream_set_timeout($socket, 8);
        try {
            if (dg_mail_smtp_reply($socket) !== 220) return false;
            if (!dg_mail_smtp_write($socket, "EHLO devicegame.com\r\n") || dg_mail_smtp_reply($socket) !== 250) return false;
            if (!dg_mail_smtp_write($socket, 'MAIL FROM:<' . DG_MAIL_FROM . ">\r\n") || dg_mail_smtp_reply($socket) !== 250) return false;
            if (!dg_mail_smtp_write($socket, 'RCPT TO:<' . (string)$message['to'] . ">\r\n")) return false;
            if (!in_array(dg_mail_smtp_reply($socket), [250, 251], true)) return false;
            if (!dg_mail_smtp_write($socket, "DATA\r\n") || dg_mail_smtp_reply($socket) !== 354) return false;
            // 7-bit base64 SMTP gövdesi; ürün anahtarı veya özel mesaj içermez.
            $body = rtrim(chunk_split(base64_encode((string)$message['body']), 76, "\r\n"));
            $headers = [
                'Date: ' . date(DATE_RFC2822),
                'Message-ID: <' . bin2hex(random_bytes(16)) . '@devicegame.com>',
                'From: Device Game <' . DG_MAIL_FROM . '>',
                'To: <' . (string)$message['to'] . '>',
                'Subject: ' . $subject,
                'MIME-Version: 1.0',
                'Content-Type: text/plain; charset=UTF-8',
                'Content-Transfer-Encoding: base64',
                'X-Mailer: Device Game',
            ];
            $data = implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.\r\n";
            if (!dg_mail_smtp_write($socket, $data)) return false;
            return dg_mail_smtp_reply($socket) === 250;
        } catch (Throwable $e) {
            return false;
        } finally {
            @fclose($socket);
        }
    }

    function dg_mail_send(array $message): bool
    {
        $subject = '=?UTF-8?B?' . base64_encode((string)$message['subject']) . '?=';
        $headers = implode("\r\n", [
            'From: Device Game <' . DG_MAIL_FROM . '>',
            'MIME-Version: 1.0',
            'Content-Type: text/plain; charset=UTF-8',
            'Content-Transfer-Encoding: 8bit',
            'X-Mailer: Device Game',
        ]);
        try {
            if (!function_exists('mail')) return dg_mail_send_local_smtp($message, $subject);
            return @mail((string)$message['to'], $subject, (string)$message['body'], $headers, '-f' . DG_MAIL_FROM);
        } catch (Throwable $e) {
            error_log('[DG mail] Gönderim servisi kullanılamıyor.');
            return false;
        }
    }

    /** Tek alıcıya dakikalar içinde aşırı e-posta gönderimini önler. */
    function dg_mail_next_recipient_time(string $address, int $now): int
    {
        $path = dg_mail_root() . '/state/recipient-' . hash('sha256', strtolower($address)) . '.json';
        $times = is_file($path) ? json_decode((string)@file_get_contents($path), true) : [];
        if (!is_array($times)) $times = [];
        $times = array_values(array_filter(array_map('intval', $times), static fn(int $t): bool => $t > $now - 3600));
        if (count($times) >= 10) return min($times) + 3600;
        return 0;
    }

    function dg_mail_record_recipient(string $address, int $now): void
    {
        $path = dg_mail_root() . '/state/recipient-' . hash('sha256', strtolower($address)) . '.json';
        $times = is_file($path) ? json_decode((string)@file_get_contents($path), true) : [];
        if (!is_array($times)) $times = [];
        $times = array_values(array_filter(array_map('intval', $times), static fn(int $t): bool => $t > $now - 3600));
        $times[] = $now;
        @file_put_contents($path, json_encode($times), LOCK_EX); @chmod($path, 0600);
    }

    function dg_mail_restore_job(string $workFile, string $queueFile, array $job): void
    {
        $json = json_encode($job, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false || @file_put_contents($workFile, $json, LOCK_EX) === false) return;
        // Aynı kullanıcı için bu sırada yeni bir özet kuyruğa alındıysa tek özet yeterlidir.
        if (is_file($queueFile) && (str_starts_with(basename($queueFile), 'social-') || str_starts_with(basename($queueFile), 'dm-'))) { @unlink($workFile); return; }
        @rename($workFile, $queueFile);
    }

    /** Cron işi; kullanıcı isteği sırasında ağ bağlantısı açılmaz. */
    function dg_mail_work(int $limit = 20): array
    {
        $counts = ['sent' => 0, 'failed' => 0, 'skipped' => 0, 'deferred' => 0];
        if (!dg_mail_prepare()) return $counts;
        $lock = @fopen(dg_mail_root() . '/worker.lock', 'c+');
        if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) { if ($lock) fclose($lock); return $counts; }
        $root = dg_mail_root();
        try {
            $now = time();
            foreach (glob($root . '/working/*.json') ?: [] as $stale) {
                if ((int)@filemtime($stale) < $now - 600) {
                    $queueFile = $root . '/queue/' . basename($stale);
                    if (!is_file($queueFile)) @rename($stale, $queueFile); else @unlink($stale);
                }
            }
            $files = glob($root . '/queue/*.json') ?: [];
            sort($files);
            $processed = 0;
            foreach ($files as $file) {
                if ($processed >= max(1, min(100, $limit))) break;
                $job = json_decode((string)@file_get_contents($file), true);
                if (!is_array($job)) { @unlink($file); $counts['skipped']++; continue; }
                if ((int)($job['created_at'] ?? 0) < $now - 7 * 86400) { @unlink($file); $counts['skipped']++; continue; }
                if ((int)($job['next_attempt'] ?? 0) > $now) continue;
                $work = $root . '/working/' . basename($file);
                if (!@rename($file, $work)) continue;
                $processed++;
                $resolved = dg_mail_resolve_job($job);
                if (!$resolved) { @unlink($work); $counts['skipped']++; continue; }
                $next = dg_mail_next_recipient_time((string)$resolved['to'], $now);
                $isSocialMail = in_array($resolved['type'], ['social', 'social_dm'], true);
                if ($isSocialMail) {
                    $lastFile = $root . '/state/social-' . (int)$resolved['user_id'] . '.txt';
                    $last = is_file($lastFile) ? (int)@file_get_contents($lastFile) : 0;
                    // Mesaj özetleri en erken bir dakika arayla; yoğunlukta alıcı limiti de uygulanır.
                    $next = max($next, $last + 60);
                }
                if ($next > $now) {
                    $job['next_attempt'] = $next;
                    dg_mail_restore_job($work, $file, $job); $counts['deferred']++; continue;
                }
                if (dg_mail_send($resolved)) {
                    dg_mail_record_recipient((string)$resolved['to'], $now);
                    if ($isSocialMail) {
                        @file_put_contents($lastFile, (string)$now, LOCK_EX); @chmod($lastFile, 0600);
                    }
                    @unlink($work); $counts['sent']++;
                } else {
                    $job['attempts'] = (int)($job['attempts'] ?? 0) + 1;
                    $job['next_attempt'] = $now + min(21600, 60 * (2 ** min(8, $job['attempts'])));
                    dg_mail_restore_job($work, $file, $job); $counts['failed']++;
                }
            }
            foreach (glob($root . '/state/*') ?: [] as $state) {
                if (is_file($state) && (int)@filemtime($state) < $now - 7 * 86400) @unlink($state);
            }
        } finally {
            @flock($lock, LOCK_UN); fclose($lock);
        }
        return $counts;
    }
}
