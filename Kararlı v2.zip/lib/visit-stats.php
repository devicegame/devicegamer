<?php
declare(strict_types=1);
/** Yalnızca günlük toplam oturum sayısı; IP veya oturum kimliği depolanmaz. */
function dg_count_session_visit(): void {
    if (PHP_SAPI === 'cli' || session_status() !== PHP_SESSION_ACTIVE) return;
    $day = date('Y-m-d');
    if (($_SESSION['dg_visit_counted_day'] ?? '') === $day) return;
    $dir = __DIR__ . '/../storage/visit-stats';
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) return;
    $f = @fopen($dir . '/' . $day . '.txt', 'c+');
    if (!$f) return;
    try {
        if (!flock($f, LOCK_EX)) return;
        $count = (int)stream_get_contents($f); rewind($f); ftruncate($f, 0); fwrite($f, (string)($count + 1)); fflush($f);
        $_SESSION['dg_visit_counted_day'] = $day;
    } finally { @flock($f, LOCK_UN); fclose($f); }
}
function dg_session_visits_today(): int {
    $file = __DIR__ . '/../storage/visit-stats/' . date('Y-m-d') . '.txt';
    return is_file($file) ? max(0, (int)@file_get_contents($file)) : 0;
}
