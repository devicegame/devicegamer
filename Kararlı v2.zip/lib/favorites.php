<?php
declare(strict_types=1);
/** Hesaba bağlı favoriler ve fiyat bildirimleri. */
function dg_favorite_items(int $userId): array {
    foreach (dg_all('users') as $row) if ((int)($row['id'] ?? 0) === $userId) return (array)($row['favorites'] ?? []);
    return [];
}
function dg_set_favorite(int $userId, array $product, bool $active): void {
    $slug = (string)$product['slug'];
    dg_mutate(static function (array &$data) use ($userId, $slug, $product, $active): void {
        $i = dg_index_of_id($data['users'], $userId);
        if ($i === null || !empty($data['users'][$i]['is_banned'])) throw new RuntimeException('Hesap kullanılamıyor.');
        $favorites = (array)($data['users'][$i]['favorites'] ?? []);
        if ($active) {
            if (!isset($favorites[$slug]) && count($favorites) >= 200) throw new RuntimeException('En fazla 200 ürün favoriye eklenebilir.');
            if (!isset($favorites[$slug])) $favorites[$slug] = ['price' => (int)$product['price'], 'added_at' => time()];
        } else unset($favorites[$slug]);
        $data['users'][$i]['favorites'] = $favorites;
    });
}
/** Cron her dakika kontrol eder; fiyat önceki kontrolden düşmüşse olaylar kalıcı tutulur. */
function dg_favorite_price_watch(): void {
    if (!dg_mail_prepare()) throw new RuntimeException('Bildirim kuyruğu kullanılamıyor.');
    $lock = fopen(dg_mail_root() . '/price-watch.lock', 'c+');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) { if ($lock) fclose($lock); return; }
    try {
        $catalog = [];
        foreach (shop_products(true) as $p) $catalog[(string)$p['slug']] = $p;
        $snapshot = dg_read_data(true);
        $needsUpdate = false;
        foreach ($snapshot['users'] as $u) foreach ((array)($u['favorites'] ?? []) as $slug => $fav) {
            if (isset($catalog[$slug]) && (int)($fav['price'] ?? -1) !== (int)$catalog[$slug]['price']) { $needsUpdate = true; break 2; }
        }
        if ($needsUpdate) {
            dg_mutate(static function (array &$data) use ($catalog): void {
                foreach ($data['users'] as &$u) {
                    if (!empty($u['is_banned']) || empty($u['favorites']) || !is_array($u['favorites'])) continue;
                    foreach ($u['favorites'] as $slug => &$fav) {
                        if (!isset($catalog[$slug]) || !is_array($fav)) continue;
                        $new = (int)$catalog[$slug]['price']; $old = (int)($fav['price'] ?? $new);
                        if ($new < $old && $new >= 0) {
                            $id = bin2hex(random_bytes(12));
                            $data['meta']['favorite_price_pending'][$id] = ['id'=>$id, 'user_id'=>(int)$u['id'], 'slug'=>$slug, 'name'=>(string)$catalog[$slug]['name'], 'old'=>$old, 'new'=>$new];
                        }
                        $fav['price'] = $new;
                    }
                    unset($fav);
                }
                unset($u);
            });
        }
        $pending = (array)(dg_read_data(true)['meta']['favorite_price_pending'] ?? []);
        foreach (array_slice($pending, 0, 100, true) as $id => $event) {
            $uid = (int)($event['user_id'] ?? 0); $slug = (string)($event['slug'] ?? '');
            if ($uid <= 0 || !preg_match('/^[a-f0-9]{24}$/', (string)$id) || !isset($catalog[$slug])) {
                dg_mutate(static function (array &$data) use ($id): void { unset($data['meta']['favorite_price_pending'][$id]); });
                continue;
            }
            $u = dg_find_user_by_id($uid);
            if (!$u || !empty($u['is_banned'])) { $done = true; }
            else {
                social_with_lock(static function () use ($uid, $id, $event, $slug): void {
                    $path = social_notifications_file($uid); $items = social_read_json($path, []);
                    foreach ($items as $item) if (($item['price_event_id'] ?? '') === $id) return;
                    array_unshift($items, ['id'=>social_next_id_locked('notifications'), 'type'=>'price_drop', 'actor_id'=>0, 'post_id'=>0, 'comment_id'=>0, 'message'=>social_clean_text((string)$event['name'], 150) . ' fiyatı ' . (int)$event['old'] . ' TL’den ' . (int)$event['new'] . ' TL’ye düştü.', 'url'=>'../product.php?slug=' . rawurlencode($slug), 'read'=>false, 'created_at'=>time(), 'price_event_id'=>$id]);
                    social_write_json_atomic($path, array_slice($items, 0, 100), false);
                });
                $done = dg_mail_enqueue(['type'=>'price_drop','user_id'=>$uid, 'slug'=>$slug, 'name'=>(string)$event['name'], 'old'=>(int)$event['old'], 'new'=>(int)$event['new']], 'price-' . $id);
            }
            if ($done) dg_mutate(static function (array &$data) use ($id): void { unset($data['meta']['favorite_price_pending'][$id]); });
        }
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
