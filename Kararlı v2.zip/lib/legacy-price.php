<?php
declare(strict_types=1);
/** Ana katalog fiyatını, diğer alanları değiştirmeden kilit altında günceller. */
function dg_update_legacy_catalog_price(string $slug, int $price, ?string $path = null, ?int $expectedPrice = null): bool {
    if ($slug === '' || $price < 1) throw new RuntimeException('Katalog fiyatı geçersiz.');
    $path = $path ?? __DIR__ . '/../storage/products.json';
    $file = @fopen($path, 'r+');
    if (!$file) throw new RuntimeException('Mağaza kataloğu açılamadı.');
    try {
        if (!flock($file, LOCK_EX)) throw new RuntimeException('Mağaza kataloğu kilitlenemedi.');
        $raw = stream_get_contents($file);
        $rows = json_decode((string)$raw, true);
        if (!is_array($rows)) throw new RuntimeException('Mağaza kataloğu okunamadı.');
        $found = false;
        foreach ($rows as &$row) {
            if (!is_array($row) || (string)($row['slug'] ?? '') !== $slug) continue;
            $found = true;
            if ($expectedPrice !== null && (int)($row['price'] ?? -1) !== $expectedPrice) throw new RuntimeException('Fiyat bu sırada değişti; lütfen tekrar deneyin.');
            if ((int)($row['price'] ?? -1) === $price) return false;
            $row['price'] = $price;
            break;
        }
        unset($row);
        if (!$found) throw new RuntimeException('Ürün mağaza kataloğunda bulunamadı.');
        $json = json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if ($json === false) throw new RuntimeException('Mağaza kataloğu kodlanamadı.');
        $payload = $json . "\n";
        rewind($file);
        if (!ftruncate($file, 0)) throw new RuntimeException('Mağaza kataloğu yazılamadı.');
        $offset = 0; $len = strlen($payload);
        while ($offset < $len) {
            $n = fwrite($file, substr($payload, $offset, 1024 * 1024));
            if ($n === false || $n === 0) {
                rewind($file); @ftruncate($file, 0); @fwrite($file, (string)$raw); @fflush($file);
                throw new RuntimeException('Mağaza kataloğu yazılamadı.');
            }
            $offset += $n;
        }
        fflush($file);
        return true;
    } finally { @flock($file, LOCK_UN); fclose($file); }
}
