<?php
declare(strict_types=1);
function dg_collections_file(): string { return __DIR__ . '/../storage/collections.json'; }
function dg_collections_read(): array {
    $file = dg_collections_file();
    if (!is_file($file)) return [];
    $data = json_decode((string)file_get_contents($file), true);
    if (!is_array($data)) throw new RuntimeException('Koleksiyon dosyası okunamadı.');
    return array_values(array_filter($data, 'is_array'));
}
function dg_collections_change(callable $callback): void {
    if (!shop_storage_guard()) throw new RuntimeException('Depolama alanı kullanılamıyor.');
    $lock = fopen(dg_collections_file() . '.lock', 'c+');
    if (!$lock) throw new RuntimeException('Koleksiyon kilidi açılamadı.');
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Koleksiyon kilitlenemedi.');
        $data = dg_collections_read();
        $callback($data);
        $json = json_encode(array_values($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) throw new RuntimeException('Koleksiyon kaydı hazırlanamadı.');
        $tmp = dg_collections_file() . '.' . bin2hex(random_bytes(8)) . '.tmp';
        if (file_put_contents($tmp, $json . "\n", LOCK_EX) === false) throw new RuntimeException('Koleksiyon kaydedilemedi.');
        @chmod($tmp, 0660);
        if (!rename($tmp, dg_collections_file())) { @unlink($tmp); throw new RuntimeException('Koleksiyon kaydedilemedi.'); }
    } finally { @flock($lock, LOCK_UN); fclose($lock); }
}
