<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/inc/helpers.php';
require_once __DIR__ . '/lib/mail.php';
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store, private');
header('X-Robots-Tag: noindex, nofollow');

// Move the bearer token out of the URL before displaying a form or loading assets.
if (isset($_GET['token'])) {
    $t = (string)$_GET['token'];
    $_SESSION['dg_reset_token'] = preg_match('/^[a-f0-9]{64}$/', $t) ? $t : '';
    header('Location: forgot-password.php?reset=1', true, 303); exit;
}
$reset = isset($_GET['reset']);
$error = ''; $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify((string)($_POST['csrf'] ?? ''))) {
        $error = 'Güvenlik doğrulaması başarısız. Sayfayı yenileyip tekrar deneyin.';
    } elseif ($reset) {
        $token = (string)($_SESSION['dg_reset_token'] ?? '');
        $p = (string)($_POST['password'] ?? '');
        $p2 = (string)($_POST['password2'] ?? '');
        $error = validate_password($p) ?? '';
        if (!$error && $p !== $p2) $error = 'Şifreler uyuşmuyor.';
        if (!$error && !preg_match('/^[a-f0-9]{64}$/', $token)) $error = 'Bağlantı geçersiz veya süresi dolmuş.';
        if (!$error) {
            try {
                $digest = hash('sha256', $token);
                $hash = password_hash($p, PASSWORD_BCRYPT);
                $ok = dg_mutate(function (array &$data) use ($digest, $hash): bool {
                    foreach ($data['users'] as &$u) {
                        if (!empty($u['reset_hash']) && (int)($u['reset_expires'] ?? 0) >= time() && hash_equals((string)$u['reset_hash'], $digest)) {
                            $u['password_hash'] = $hash;
                            unset($u['reset_hash'], $u['reset_expires']);
                            return true;
                        }
                    }
                    return false;
                });
                if ($ok) { unset($_SESSION['dg_reset_token']); flash_set('Şifreniz değiştirildi. Yeni şifrenizle giriş yapabilirsiniz.'); header('Location: login.php', true, 303); exit; }
                $error = 'Bağlantı geçersiz veya süresi dolmuş. Yeni bir bağlantı isteyin.';
            } catch (Throwable $e) { error_log('[password reset] ' . $e->getMessage()); $error = 'İşlem tamamlanamadı. Lütfen daha sonra tekrar deneyin.'; }
        }
    } else {
        $email = trim((string)($_POST['email'] ?? ''));
        $message = 'Bu adresle kayıtlı bir hesap varsa şifre sıfırlama bağlantısı gönderilecektir. Son 5 dakika içinde istek gönderdiyseniz yeni bir bağlantı için 5 dakika dolmasını bekleyin. Gelen kutunuzu ve spam klasörünü kontrol edin.';
        if (strlen($email) <= 254 && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            try {
                $token = bin2hex(random_bytes(32)); $digest = hash('sha256', $token); $now = time();
                $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
                $ipKey = hash('sha256', $ip);
                $recipient = dg_mutate(function (array &$data) use ($email, $digest, $now, $ipKey): string {
                    $limits = $data['meta']['reset_limits'] ?? [];
                    if (!is_array($limits)) $limits = [];
                    foreach ($limits as $k => $v) if (!is_array($v) || (int)($v['until'] ?? 0) < $now) unset($limits[$k]);
                    $bucket = $limits[$ipKey] ?? ['until' => $now + 3600, 'count' => 0];
                    $bucket['count'] = (int)$bucket['count'] + 1; $limits[$ipKey] = $bucket;
                    $data['meta']['reset_limits'] = $limits;
                    if ($bucket['count'] > 10) return '';
                    foreach ($data['users'] as &$u) {
                        if (dg_casefold((string)($u['email'] ?? '')) !== dg_casefold($email)) continue;
                        if ((int)($u['reset_requested_at'] ?? 0) > $now - 300 || !empty($u['is_banned'])) return '';
                        $u['reset_hash'] = $digest; $u['reset_expires'] = $now + 1800; $u['reset_requested_at'] = $now;
                        return (string)$u['email'];
                    }
                    return '';
                });
                if ($recipient !== '') {
                    $url = 'https://devicegame.com/forgot-password.php?token=' . $token;
                    $body = "Merhaba,\n\nDeviceGame şifrenizi sıfırlamak için aşağıdaki bağlantıyı açın:\n\n" . $url . "\n\nBağlantı 30 dakika geçerlidir ve yalnızca bir kez kullanılabilir. Bu isteği siz yapmadıysanız bu e-postayı yok sayabilirsiniz.\n\nDeviceGame";
                    if (!dg_mail_send(['to' => $recipient, 'subject' => 'DeviceGame şifre sıfırlama', 'body' => $body])) {
                        error_log('[password reset] SMTP submission failed');
                    }
                }
            } catch (Throwable $e) { error_log('[password reset] ' . $e->getMessage()); }
        }
    }
}
$page_title = $reset ? 'Yeni şifre belirle' : 'Şifremi unuttum';
$page_canonical = false; $page_robots = 'noindex,nofollow';
$page_css = ['shop.css', 'assets/css/dcoin.css']; $body_class = 'shop-page auth-page';
include __DIR__ . '/header.php';
?>
<section class="auth-section"><div class="auth-layout"><div class="auth-card">
<p class="eyebrow">Hesabım</p>
<h1><?php echo $reset ? 'Yeni şifre belirle' : 'Şifremi unuttum'; ?></h1>
<p class="auth-intro"><?php echo $reset ? 'Hesabınız için yeni bir şifre seçin.' : 'Hesabınızda kullandığınız e-posta adresini girin.'; ?></p>
<?php if ($error): ?><div class="auth-alert is-error" role="alert"><?php echo e($error); ?></div><?php endif; ?>
<?php if ($message): ?><div class="auth-alert is-success" role="status"><?php echo e($message); ?></div><?php endif; ?>
<?php if (!$message): ?>
<form method="post" action="<?php echo $reset ? 'forgot-password.php?reset=1' : 'forgot-password.php'; ?>" class="auth-form">
<?php echo csrf_field(); ?>
<?php if ($reset): ?>
<div class="field"><label for="password">Yeni şifre</label><input id="password" name="password" type="password" autocomplete="new-password" minlength="6" maxlength="72" required></div>
<div class="field"><label for="password2">Yeni şifre tekrar</label><input id="password2" name="password2" type="password" autocomplete="new-password" minlength="6" maxlength="72" required></div>
<button class="btn btn-primary btn-full" type="submit">Şifreyi değiştir</button>
<?php else: ?>
<div class="field"><label for="email">E-posta adresi</label><input id="email" name="email" type="email" maxlength="254" autocomplete="email" required></div>
<button class="btn btn-primary btn-full" type="submit">Sıfırlama bağlantısı gönder</button>
<?php endif; ?>
</form><?php endif; ?>
<div class="auth-foot"><p><a href="login.php">Giriş sayfasına dön</a></p></div>
</div></div></section>
<?php include __DIR__ . '/footer.php'; ?>
