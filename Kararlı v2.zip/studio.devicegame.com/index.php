<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Device Game Studio — Sınırları zorlayan evrenler kuruyoruz.</title>
    <meta name="description" content="Device Game Studio: İzmir merkezli oyun stüdyosu. Hikaye anlatımı, yeni nesil grafikler ve oyuncu odaklı tasarım. Project: Overcharge geliştirme aşamasında.">
    <meta property="og:title" content="Device Game Studio">
    <meta property="og:description" content="Sınırları zorlayan hikayeler, yeni nesil evrenler. İzmir'den dünyaya.">
    <meta property="og:type" content="website">
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Cdefs%3E%3ClinearGradient id='g'%3E%3Cstop stop-color='%23b983ff'/%3E%3Cstop offset='.55' stop-color='%23ffe67a'/%3E%3Cstop offset='1' stop-color='%23b8f46d'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='32' height='32' rx='9' fill='%23120b24'/%3E%3Cpath d='M8 16h16M16 8v16' stroke='url(%23g)' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E">
    <style>

/* ============ Temel ============ */
*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; }
body {
    margin: 0;
    color: var(--dg-text);
    background: #0a0d16;
    font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
    -webkit-font-smoothing: antialiased;
}
img { max-width: 100%; display: block; }
section[id] { scroll-margin-top: 96px; }
::selection { background: rgba(169, 149, 255, 0.35); }

/* ============ Menü ============ */
#site-nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 50;
    padding: 1.15rem 0;
    transition: background 0.25s ease, padding 0.25s ease, box-shadow 0.25s ease;
}
#site-nav.scrolled {
    padding: 0.7rem 0;
    background: rgba(10, 13, 22, 0.78);
    -webkit-backdrop-filter: blur(14px); backdrop-filter: blur(14px);
    box-shadow: 0 14px 44px rgba(0, 0, 0, 0.38);
    border-bottom: 1px solid var(--dg-border);
}
.nav-container {
    width: min(1200px, calc(100% - 32px)); margin-inline: auto;
    display: flex; align-items: center; justify-content: space-between; gap: 1.5rem;
}
.nav-brand {
    display: inline-flex; align-items: baseline;
    color: var(--dg-text); font-size: 1.28rem; font-weight: 850; letter-spacing: -0.05em; text-decoration: none;
}
.nav-brand .dot { color: var(--dg-accent); }
.nav-brand .studio-tag {
    margin-left: 0.5rem; color: var(--dg-muted);
    font-size: 0.62rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase;
}
.nav-links { display: flex; gap: 1.75rem; }
.nav-links a {
    color: var(--dg-muted); font-size: 0.92rem; font-weight: 600; text-decoration: none;
    transition: color 0.2s ease;
}
.nav-links a:hover { color: var(--dg-text); }
.nav-cta {
    display: inline-flex; align-items: center; justify-content: center;
    min-height: 42px; padding: 0.55rem 1.05rem; border: 1px solid transparent; border-radius: 11px;
    color: #151126; background: linear-gradient(135deg, #b7a5ff, #81dcf5);
    font-size: 0.88rem; font-weight: 700; text-decoration: none;
    transition: transform 0.2s ease, background 0.2s ease;
}
.nav-cta:hover { transform: translateY(-2px); background: linear-gradient(135deg, #c9bcff, #a5eafd); }
#site-nav a:focus-visible { outline: 2px solid #c3b6ff; outline-offset: 4px; }
@media (max-width: 760px) { .nav-links { display: none; } }

/* ============ Hero ============ */
.hero {
    position: relative; isolation: isolate; overflow: hidden;
    --mx: 68%; --my: 32%;
    padding: clamp(8.5rem, 17vh, 11.5rem) 0 clamp(3.25rem, 7vh, 5.5rem);
}
.hero::before {
    content: ""; position: absolute; inset: 0; z-index: -1;
    background:
        radial-gradient(620px circle at var(--mx) var(--my), rgba(169, 149, 255, 0.17), transparent 65%),
        radial-gradient(900px circle at 88% 8%, rgba(72, 196, 218, 0.10), transparent 60%),
        radial-gradient(760px circle at 6% 92%, rgba(129, 94, 255, 0.13), transparent 62%);
}
.eyebrow {
    margin: 0 0 1rem; color: #b8a8ff;
    font-size: 0.75rem; font-weight: 800; letter-spacing: 0.15em; text-transform: uppercase;
}
.hero h1 {
    max-width: 15ch; margin: 0 0 1.35rem;
    font-size: clamp(2.65rem, 7vw, 5.3rem); line-height: 1.03; letter-spacing: -0.048em;
}
.hero h1 .grad {
    background: linear-gradient(135deg, #b7a5ff, #81dcf5);
    -webkit-background-clip: text; background-clip: text; color: transparent;
}
.hero .lead {
    max-width: 56ch; margin: 0 0 2.35rem; color: #c0c9da;
    font-size: clamp(1.02rem, 2vw, 1.22rem); line-height: 1.75;
}
.hero-actions { display: flex; flex-wrap: wrap; gap: 0.85rem; margin-bottom: 2.75rem; }
.btn {
    display: inline-flex; min-height: 52px; align-items: center; justify-content: center; gap: 0.6rem;
    padding: 0.85rem 1.35rem; border: 1px solid transparent; border-radius: 12px;
    font-size: 0.95rem; font-weight: 700; line-height: 1.3; text-align: center; text-decoration: none;
    transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
}
.btn:hover { transform: translateY(-2px); }
.btn-primary { color: #151126; background: linear-gradient(135deg, #b7a5ff, #81dcf5); }
.btn-primary:hover { background: linear-gradient(135deg, #c9bcff, #a5eafd); }
.btn-ghost {
    border-color: rgba(255, 255, 255, 0.16); color: var(--dg-text); background: rgba(255, 255, 255, 0.04);
}
.btn-ghost:hover { border-color: rgba(169, 149, 255, 0.7); background: rgba(169, 149, 255, 0.1); }
.hero-meta {
    display: flex; flex-wrap: wrap; gap: 0.75rem 2.25rem;
    padding-top: 1.25rem; border-top: 1px solid var(--dg-border);
    color: var(--dg-muted); font-size: 0.92rem;
}
.hero-meta .pulse {
    display: inline-block; width: 8px; height: 8px; margin-right: 0.55rem; border-radius: 50%;
    background: #81dcf5; box-shadow: 0 0 0 0 rgba(129, 220, 245, 0.5);
    animation: dg-pulse 2.2s infinite; vertical-align: 1px;
}
@keyframes dg-pulse {
    0% { box-shadow: 0 0 0 0 rgba(129, 220, 245, 0.5); }
    70% { box-shadow: 0 0 0 9px rgba(129, 220, 245, 0); }
    100% { box-shadow: 0 0 0 0 rgba(129, 220, 245, 0); }
}

/* ============ İçerik bölümleri ============ */
.section { padding: clamp(3.25rem, 8vw, 6.25rem) 0 0; }
.sec-head { max-width: 660px; margin-bottom: clamp(2rem, 5vw, 3.1rem); }
.sec-head h2 {
    margin: 0 0 1rem; font-size: clamp(1.95rem, 4.2vw, 2.95rem);
    line-height: 1.08; letter-spacing: -0.042em;
}
.sec-head p { margin: 0; color: #c0c9da; font-size: 1.02rem; line-height: 1.75; }

.cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1.15rem; }
.card {
    padding: 1.85rem 1.75rem; border: 1px solid var(--dg-border); border-radius: 22px;
    background: #111522;
    transition: transform 0.25s ease, border-color 0.25s ease;
}
.card:hover { transform: translateY(-4px); border-color: rgba(169, 149, 255, 0.35); }
.card .glyph {
    display: grid; place-items: center; width: 46px; height: 46px; margin-bottom: 1.15rem;
    border-radius: 13px; background: rgba(169, 149, 255, 0.12); font-size: 1.35rem;
}
.card h3 { margin: 0 0 0.6rem; font-size: 1.12rem; letter-spacing: -0.02em; }
.card p { margin: 0; color: var(--dg-muted); font-size: 0.94rem; line-height: 1.7; }

.project-card {
    display: grid; grid-template-columns: minmax(0, 1.35fr) minmax(0, 1fr); gap: clamp(1.5rem, 4vw, 3rem);
    align-items: center;
    padding: clamp(1.75rem, 4vw, 2.75rem); border: 1px solid rgba(169, 149, 255, 0.25); border-radius: 28px;
    background:
        radial-gradient(circle at 0% 0%, rgba(129, 94, 255, 0.2), transparent 46%),
        radial-gradient(circle at 100% 100%, rgba(48, 196, 218, 0.1), transparent 42%),
        #111522;
    box-shadow: 0 24px 70px rgba(0, 0, 0, 0.2);
}
.badge {
    display: inline-flex; align-items: center; gap: 0.5rem;
    margin-bottom: 1.15rem; padding: 0.42rem 0.85rem; border-radius: 999px;
    border: 1px solid rgba(169, 149, 255, 0.3); background: rgba(169, 149, 255, 0.1);
    color: #d3caff; font-size: 0.72rem; font-weight: 800; letter-spacing: 0.11em; text-transform: uppercase;
}
.project-card h3 { margin: 0 0 0.85rem; font-size: clamp(1.65rem, 3.4vw, 2.35rem); letter-spacing: -0.04em; }
.project-card p { margin: 0 0 1.45rem; color: #c0c9da; line-height: 1.75; }
.chips { display: flex; flex-wrap: wrap; gap: 0.55rem; }
.chip {
    padding: 0.45rem 0.85rem; border: 1px solid var(--dg-border); border-radius: 999px;
    color: var(--dg-muted); font-size: 0.78rem; font-weight: 650;
}
.project-aside {
    padding: 1.5rem; border: 1px dashed rgba(169, 149, 255, 0.3); border-radius: 20px;
    background: rgba(169, 149, 255, 0.06);
}
.project-aside h4 { margin: 0 0 0.55rem; font-size: 0.98rem; letter-spacing: -0.02em; }
.project-aside p { margin: 0; color: var(--dg-muted); font-size: 0.88rem; line-height: 1.7; }

.steps { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 1.15rem; }
.step {
    padding: 1.65rem 1.5rem; border: 1px solid var(--dg-border); border-radius: 20px; background: #0f1320;
}
.step .num {
    display: block; margin-bottom: 0.9rem;
    background: linear-gradient(135deg, #b7a5ff, #81dcf5);
    -webkit-background-clip: text; background-clip: text; color: transparent;
    font-size: 1.65rem; font-weight: 850; letter-spacing: -0.04em;
}
.step h3 { margin: 0 0 0.55rem; font-size: 1.02rem; letter-spacing: -0.02em; }
.step p { margin: 0; color: var(--dg-muted); font-size: 0.88rem; line-height: 1.7; }

@media (prefers-reduced-motion: no-preference) {
    [data-reveal].in { animation: dg-reveal 0.65s cubic-bezier(0.2, 0.7, 0.2, 1) both; }
    .hero .pulse { animation: dg-pulse 2.2s infinite; }
}
@media (max-width: 980px) {
    .cards { grid-template-columns: 1fr 1fr; }
    .steps { grid-template-columns: 1fr 1fr; }
    .project-card { grid-template-columns: 1fr; }
}
@media (max-width: 640px) {
    .cards { grid-template-columns: 1fr; }
    .steps { grid-template-columns: 1fr; }
}

/* Device Game Studio — iletişim alanı ve footer */
:root {
    --dg-text: #f5f6ff;
    --dg-muted: #aab4c8;
    --dg-accent: #a995ff;
    --dg-border: rgba(255, 255, 255, 0.1);
}

.wrap {
    width: min(1200px, calc(100% - 32px));
    margin-inline: auto;
}

.cta,
.cta *,
.site-footer,
.site-footer * {
    box-sizing: border-box;
}

/* İletişim */
.cta {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(220px, 260px);
    align-items: center;
    gap: clamp(2rem, 5vw, 5rem);
    margin-block: clamp(3rem, 6vw, 5rem);
    padding: clamp(2rem, 5vw, 4rem);
    overflow: hidden;
    border: 1px solid rgba(169, 149, 255, 0.25);
    border-radius: 28px;
    color: var(--dg-text);
    background:
        radial-gradient(circle at 0% 0%, rgba(129, 94, 255, 0.22), transparent 48%),
        radial-gradient(circle at 100% 100%, rgba(48, 196, 218, 0.1), transparent 42%),
        #111522;
    box-shadow: 0 24px 70px rgba(0, 0, 0, 0.2);
    font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
}

.cta .eyebrow {
    margin: 0 0 1rem;
    color: #b8a8ff;
    font-size: 0.75rem;
    font-weight: 800;
    letter-spacing: 0.15em;
    text-transform: uppercase;
}

.cta h2 {
    max-width: 16ch;
    margin: 0 0 1rem;
    font-size: clamp(2rem, 4.5vw, 3.5rem);
    line-height: 1.08;
    letter-spacing: -0.04em;
}

.cta p:not(.eyebrow) {
    max-width: 58ch;
    margin: 0;
    color: #c0c9da;
    font-size: 1rem;
    line-height: 1.75;
}

.cta-actions {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.cta-actions .btn {
    display: inline-flex;
    min-height: 52px;
    align-items: center;
    justify-content: center;
    gap: 0.6rem;
    padding: 0.85rem 1.25rem;
    border: 1px solid transparent;
    border-radius: 12px;
    font-size: 0.95rem;
    font-weight: 700;
    line-height: 1.3;
    text-align: center;
    text-decoration: none;
    transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
}

.cta-actions .btn svg {
    flex-shrink: 0;
}

.cta-actions .btn:hover {
    transform: translateY(-2px);
}

.cta-actions .btn-primary {
    color: #151126;
    background: linear-gradient(135deg, #b7a5ff, #81dcf5);
}

.cta-actions .btn-primary:hover {
    background: linear-gradient(135deg, #c9bcff, #a5eafd);
}

.cta-actions .btn-ghost {
    border-color: rgba(255, 255, 255, 0.16);
    color: var(--dg-text);
    background: rgba(255, 255, 255, 0.04);
}

.cta-actions .btn-ghost:hover {
    border-color: rgba(169, 149, 255, 0.7);
    background: rgba(169, 149, 255, 0.1);
}

/* Footer */
.site-footer {
    padding: clamp(3rem, 6vw, 5rem) 0 1.75rem;
    border-top: 1px solid var(--dg-border);
    color: var(--dg-muted);
    background: #090c15;
    font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
}

.footer-grid {
    display: grid;
    grid-template-columns: minmax(0, 1.6fr) repeat(3, minmax(0, 1fr));
    gap: 2.5rem;
}

.footer-brand .brand {
    display: inline-flex;
    align-items: baseline;
    color: var(--dg-text);
    font-size: 1.4rem;
    font-weight: 850;
    letter-spacing: -0.05em;
    text-decoration: none;
}

.footer-brand .dot {
    color: var(--dg-accent);
}

.footer-brand .studio-tag {
    margin-left: 0.5rem;
    color: var(--dg-muted);
    font-size: 0.65rem;
    font-weight: 700;
    letter-spacing: 0.12em;
    text-transform: uppercase;
}

.footer-brand p {
    max-width: 32ch;
    margin: 1rem 0 0;
    font-size: 0.9rem;
    line-height: 1.7;
}

.footer-col {
    display: flex;
    min-width: 0;
    flex-direction: column;
    align-items: flex-start;
    gap: 0.75rem;
}

.footer-col h2 {
    margin: 0 0 0.4rem;
    color: var(--dg-text);
    font-size: 0.8rem;
    font-weight: 750;
    letter-spacing: 0.08em;
    text-transform: uppercase;
}

.footer-col a,
.footer-col span {
    color: var(--dg-muted);
    font-size: 0.9rem;
    line-height: 1.5;
    overflow-wrap: anywhere;
    text-decoration: none;
}

.footer-col a {
    transition: color 0.2s ease;
}

.footer-col a:hover {
    color: #d3caff;
}

.footer-bottom {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 0.5rem 2rem;
    margin-top: 3.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid var(--dg-border);
    font-size: 0.8rem;
    line-height: 1.6;
}

.footer-bottom p {
    margin: 0;
}

.cta a:focus-visible,
.site-footer a:focus-visible {
    outline: 2px solid #c3b6ff;
    outline-offset: 4px;
}

/* JavaScript .in sınıfını eklediğinde animasyon oynar.
   JavaScript kapalıysa içerik yine görünür kalır. */
@media (prefers-reduced-motion: no-preference) {
    .cta[data-reveal].in {
        animation: dg-reveal 0.65s cubic-bezier(0.2, 0.7, 0.2, 1) both;
    }
}

@keyframes dg-reveal {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 900px) {
    .footer-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 700px) {
    .cta {
        grid-template-columns: 1fr;
        border-radius: 22px;
    }

    .cta h2 {
        max-width: none;
    }
}

@media (max-width: 520px) {
    .footer-brand,
    .footer-col:last-child {
        grid-column: 1 / -1;
    }

    .footer-bottom {
        flex-direction: column;
    }
}

@media (prefers-reduced-motion: reduce) {
    .cta-actions .btn,
    .footer-col a {
        transition: none;
    }

    .cta-actions .btn:hover {
        transform: none;
    }
}
    </style>
</head>
<body>
<header id="site-nav">
    <div class="nav-container">
        <a href="#" class="nav-brand">device game<span class="dot">.</span><span class="studio-tag">studio</span></a>
        <nav class="nav-links" aria-label="Ana menü">
            <a href="#studio">Stüdyo</a>
            <a href="#projeler">Projeler</a>
            <a href="#surec">Süreç</a>
            <a href="#iletisim">İletişim</a>
        </nav>
        <a class="nav-cta" href="https://devicegame.com" target="_blank" rel="noopener">Ana site</a>
    </div>
</header>

<main>
    <section class="hero" data-reveal>
        <div class="wrap">
            <p class="eyebrow">Device Game Studio · İzmir</p>
            <h1>Sınırları zorlayan <span class="grad">evrenler</span> kuruyoruz.</h1>
            <p class="lead">
                Hikaye anlatımını, yeni nesil grafikleri ve oyuncu odaklı tasarımı bir araya getiriyoruz.
                İzmir'den doğan oyunlar, dünyanın her yerindeki oyuncular için.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary" href="#projeler">Projeleri gör</a>
                <a class="btn btn-ghost" href="#iletisim">Bizimle çalış</a>
            </div>
            <div class="hero-meta">
                <span><span class="pulse" aria-hidden="true"></span>Project: Overcharge · Geliştirme aşamasında</span>
                <span>Torbalı, İzmir</span>
            </div>
        </div>
    </section>

    <section class="section" id="studio" data-reveal>
        <div class="wrap">
            <div class="sec-head">
                <p class="eyebrow">Stüdyo</p>
                <h2>Küçük bir ekip, büyük evrenler.</h2>
                <p>
                    Device Game Studio; sınırları zorlayan hikayeleri ve yeni nesil grafiklerle örülmüş
                    evrenleri hayata geçiren yaratıcı ekip. Her projede tek bir hedef var:
                    oyuncunun aklında kalacak bir dünya bırakmak.
                </p>
            </div>
            <div class="cards">
                <article class="card">
                    <div class="glyph" aria-hidden="true">✦</div>
                    <h3>Hikâye &amp; Evren</h3>
                    <p>Karakterleri, dünyaları ve mitolojileri baştan sona biz kuruyoruz. Her detayın bir nedeni var.</p>
                </article>
                <article class="card">
                    <div class="glyph" aria-hidden="true">◈</div>
                    <h3>Yeni Nesil Görsellik</h3>
                    <p>Işık, atmosfer ve grafiklerle oyuncuyu içine çeken sahneler tasarlıyoruz.</p>
                </article>
                <article class="card">
                    <div class="glyph" aria-hidden="true">◉</div>
                    <h3>Oyuncu Odaklı</h3>
                    <p>Topluluğun sesini dinliyor; oyunu oyuncularla birlikte büyütüyoruz.</p>
                </article>
            </div>
        </div>
    </section>

    <section class="section" id="projeler" data-reveal>
        <div class="wrap">
            <div class="sec-head">
                <p class="eyebrow">Projeler</p>
                <h2>Üzerinde çalıştıklarımız.</h2>
            </div>
            <div class="project-card">
                <div>
                    <span class="badge"><span class="pulse" aria-hidden="true"></span>Geliştirme aşamasında</span>
                    <h3>Project: Overcharge</h3>
                    <p>
                        Stüdyonun ilk büyük oyunu. Detaylı bir evren, güçlü bir hikaye ve yeni nesil
                        bir görsel dil üzerinde çalışıyoruz. Detaylar yakında.
                    </p>
                    <div class="chips">
                        <span class="chip">Aksiyon</span>
                        <span class="chip">Hikâye odaklı</span>
                        <span class="chip">PC</span>
                    </div>
                </div>
                <aside class="project-aside">
                    <h4>Sırada ne var?</h4>
                    <p>İkinci evren için ilk çizgiler çizildi. Project: Overcharge yolculuğuna katılmak istersen bize yaz.</p>
                </aside>
            </div>
        </div>
    </section>

    <section class="section" id="surec" data-reveal>
        <div class="wrap">
            <div class="sec-head">
                <p class="eyebrow">Süreç</p>
                <h2>Fikirden yayına.</h2>
            </div>
            <div class="steps">
                <article class="step">
                    <span class="num">01</span>
                    <h3>Fikir &amp; Konsept</h3>
                    <p>Çekirdek fikri, dünyayı ve oyuncunun yolculuğunu birlikte tanımlıyoruz.</p>
                </article>
                <article class="step">
                    <span class="num">02</span>
                    <h3>Prototip</h3>
                    <p>Oynanışı hızlıca deniyor; eğlenceli olanı bulup gerisini kesiyoruz.</p>
                </article>
                <article class="step">
                    <span class="num">03</span>
                    <h3>Geliştirme</h3>
                    <p>Sanat, kod ve ses aynı evrende buluşuyor; oyun her gün biraz daha tamamlanıyor.</p>
                </article>
                <article class="step">
                    <span class="num">04</span>
                    <h3>Yayın &amp; Destek</h3>
                    <p>Yayın bir son değil, başlangıç: toplulukla birlikte büyümeye devam ediyoruz.</p>
                </article>
            </div>
        </div>
    </section>

    <section id="iletisim">

        <div class="wrap">
            <div class="cta" data-reveal>
                <div>
                    <p class="eyebrow">İletişim</p>
                    <h2>Birlikte bir evren kuralım.</h2>
                    <p>
                        Yayıncı, sanatçı, geliştirici ya da sadece iyi bir fikri olan biri — kapımız açık.
                        Projeni anlat; 48 saat içinde dönelim.
                    </p>
                </div>
                <div class="cta-actions">
                    <a class="btn btn-primary"
                       href="https://wa.me/905519578350?text=Merhaba%2C%20Device%20Game%20Studio%20ile%20ileti%C5%9Fime%20ge%C3%A7mek%20istiyorum."
                       target="_blank" rel="noopener">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12.04 2c-5.46 0-9.9 4.44-9.9 9.9 0 1.75.46 3.45 1.32 4.95L2 22l5.3-1.39a9.86 9.86 0 0 0 4.73 1.2h.01c5.46 0 9.9-4.44 9.9-9.9 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm4.52 13.86c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-2-1.23-.74-.66-1.24-1.47-1.38-1.72-.14-.25-.02-.38.11-.51.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.17 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.47-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.14-1.18-.06-.11-.22-.17-.47-.29Z"/></svg>
                        WhatsApp'tan yaz
                    </a>
                    <a class="btn btn-ghost" href="mailto:info@devicegame.com">E-posta gönder</a>
                    <a class="btn btn-ghost" href="https://devicegame.com/shop.php" target="_blank" rel="noopener">Mağazayı ziyaret et</a>
                </div>
            </div>
        </div>
    </section>

</main>

<footer class="site-footer">
    <div class="wrap">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="#" class="brand">device game<span class="dot">.</span><span class="studio-tag">studio</span></a>
                <p>Oyun dünyasının anahtarı. Sınırları zorlayan hikayeler, yeni nesil evrenler.</p>
            </div>

            <nav class="footer-col" aria-label="Site">
                <h2>Studio</h2>
                <a href="#studio">Stüdyo</a>
                <a href="#projeler">Projeler</a>
                <a href="#surec">Süreç</a>
                <a href="#iletisim">İletişim</a>
            </nav>

            <nav class="footer-col" aria-label="Device Game dünyası">
                <h2>Device Game</h2>
                <a href="https://devicegame.com" target="_blank" rel="noopener">Ana site</a>
                <a href="https://devicegame.com/shop.php" target="_blank" rel="noopener">Mağaza</a>
                <a href="https://devicegame.com/about.php" target="_blank" rel="noopener">Vizyonumuz</a>
                <a href="https://devicegame.com/contact.php" target="_blank" rel="noopener">İletişim</a>
            </nav>

            <div class="footer-col">
                <h2>Bize ulaşın</h2>
                <a href="mailto:info@devicegame.com">info@devicegame.com</a>
                <a href="https://wa.me/905519578350" target="_blank" rel="noopener">WhatsApp ile yaz</a>
                <span>Torbalı, İzmir</span>
            </div>
        </div>

        <div class="footer-bottom">
            <p>© <span id="year">2026</span> Device Game Studio. Tüm hakları saklıdır.</p>
            <p>Stüdyo İzmir'de · Oyunlar her yerde</p>
        </div>
    </div>
</footer>
    <script>

    // Menü: kaydırınca buzlu cam
    (function () {
        var nav = document.getElementById('site-nav');
        if (!nav) return;
        function onScroll() {
            nav.classList.toggle('scrolled', window.scrollY > 24);
        }
        window.addEventListener('scroll', onScroll, { passive: true });
        onScroll();
    })();

    // Hero: imleci takip eden ışık (yalnızca fare)
    (function () {
        var hero = document.querySelector('.hero');
        if (!hero || !window.matchMedia('(hover: hover)').matches) return;
        var frame = null;
        hero.addEventListener('pointermove', function (ev) {
            if (frame) return;
            frame = requestAnimationFrame(function () {
                var r = hero.getBoundingClientRect();
                hero.style.setProperty('--mx', (ev.clientX - r.left) + 'px');
                hero.style.setProperty('--my', (ev.clientY - r.top) + 'px');
                frame = null;
            });
        });
    })();

    // Kaydırınca beliren içerik
    (function () {
        var items = document.querySelectorAll('[data-reveal]');
        if (!items.length) return;
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches ||
            !('IntersectionObserver' in window)) {
            items.forEach(function (el) { el.classList.add('in'); });
            return;
        }
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in');
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
        items.forEach(function (el) { io.observe(el); });
    })();

    // Yıl
    (function () {
        var year = document.getElementById('year');
        if (year) year.textContent = String(new Date().getFullYear());
    })();
    </script>
</body>
</html>
