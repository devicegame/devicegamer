<?php
$page_title = 'Ön Bilgilendirme Formu';
$page_canonical = 'on-bilgilendirme.php';
$page_og_type = 'article';
$page_og_title = 'Ön Bilgilendirme Formu';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">Ön Bilgilendirme Formu</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Sipariş öncesi bilmeniz gerekenler.</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                Bu form, 6502 sayılı Tüketicinin Korunması Hakkında Kanun ve Mesafeli Sözleşmeler
                Yönetmeliği uyarınca bilgilendirme amacıyla hazırlanmıştır. Mesafeli Satış Sözleşmesi'nin
                ayrılmaz parçasıdır.
            </p>

            <?php include 'legal-satici.php'; ?>

            <div class="story-block">
                <h3>Alıcı bilgileri</h3>
                <p>
                    Sipariş sırasında ad soyad, e-posta adresi (opsiyonel) ve varsa sipariş notu bilgileri
                    toplanır. Bu bilgiler yalnızca siparişin hazırlanması, teslimi ve yasal yükümlülüklerin
                    yerine getirilmesi amacıyla kullanılır.
                </p>
            </div>

            <div class="story-block">
                <h3>Sözleşme konusu ürün veya hizmet</h3>
                <p>
                    Ürünlerin türü, adedi, vergiler dâhil satış bedeli, ödeme şekli ve teslimat bilgileri
                    sipariş özetinde belirtilir. Sattığımız ürünler iki başlıkta toplanır:
                </p>
                <ul>
                    <li><strong>Dijital ürünler:</strong> oyun anahtarları (key) ve dijital hesaplar.</li>
                    <li><strong>Fiziksel ürünler:</strong> oyuncu ekipmanları ve baskılı ürünler (kişiye özel tasarımlar dâhil).</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Ödeme ve teslimat</h3>
                <ul>
                    <li>Ödeme, sipariş teyidi sonrasında <strong>Havale / EFT</strong> ile yapılır; ödeme bilgileri WhatsApp üzerinden iletilir.</li>
                    <li><strong>Dijital ürünler</strong>, ödemenin onaylanmasından sonra e-posta veya WhatsApp üzerinden dijital ortamda teslim edilir.</li>
                    <li><strong>Fiziksel ürünler</strong>, ödeme onayından sonra kargo ile gönderilir; tahmini teslim süresi sipariş teyidinde bildirilir.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Cayma hakkı</h3>
                <p>
                    Alıcı, teslim tarihinden itibaren <strong>14 gün</strong> içinde hiçbir gerekçe göstermeksizin
                    ve cezai şart ödemeksizin sözleşmeden cayma hakkına sahiptir. Cayma bildirimi;
                    <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a> adresine,
                    WhatsApp hattımıza ya da satıcı adresine yazılı olarak yapılabilir.
                </p>
                <p>
                    <strong>Önemli istisna:</strong> Mesafeli Sözleşmeler Yönetmeliği madde 15/1-ğ uyarınca,
                    elektronik ortamda anında ifa edilen hizmetler ile tüketiciye anında teslim edilen
                    gayrimaddi mallarda (teslim edilen <strong>dijital oyun anahtarı ve dijital hesaplarda</strong>)
                    cayma hakkı kullanılamaz. Hatalı veya çalışmayan ürünlerde ayıplı mal hükümleri saklıdır.
                </p>
                <p>Ayrıntılı bilgi için: <a class="text-link" href="iade-kosullari.php">İade ve Değişim Koşulları</a></p>
            </div>

            <div class="story-block">
                <h3>Fiyat ve geçerlilik</h3>
                <p>
                    Tüm fiyatlar Türk lirası (TL) cinsindendir ve önceden haber verilmeksizin güncellenebilir.
                    Geçerli fiyat, siparişin onaylandığı andaki sipariş özetinde gösterilen bedeldir. Siparişin
                    onaylanması ile bu Ön Bilgilendirme Formu ve Mesafeli Satış Sözleşmesi elektronik ortamda
                    onaylanmış sayılır.
                </p>
            </div>

            <div class="story-block">
                <h3>Uyuşmazlıkların çözümü</h3>
                <p>
                    Uyuşmazlıklarda, ilgili mevzuatta belirtilen parasal sınırlar dâhilinde Alıcı'nın yerleşim
                    yerindeki veya işlemin yapıldığı yerdeki Tüketici Hakem Heyetleri ile Tüketici Mahkemeleri
                    yetkilidir.
                </p>
            </div>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
