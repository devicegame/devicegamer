(() => {
  const source = document.getElementById('dg-collection-catalog');
  const input = document.getElementById('collection-search');
  const textarea = document.getElementById('collection-slugs');
  const results = document.getElementById('collection-results');
  const count = document.getElementById('collection-selected-count');
  if (!source || !input || !textarea || !results) return;
  let products; try { products = JSON.parse(source.textContent); } catch (_) { return; }
  const selected = () => new Set(textarea.value.split(/[\n,]+/).map(s => s.trim()).filter(Boolean));
  const fold = s => String(s).toLocaleLowerCase('tr-TR').replace(/[çğıöşü]/g, c => ({ç:'c',ğ:'g',ı:'i',ö:'o',ş:'s',ü:'u'}[c]));
  const render = () => {
    const current = selected(); if (count) count.textContent = String(current.size);
    const terms = fold(input.value).trim().split(/\s+/).filter(Boolean);
    results.replaceChildren();
    if (!terms.length) { const hint=document.createElement('p'); hint.textContent='Ürün aramak için yazmaya başla.'; hint.style.padding='10px'; results.append(hint); return; }
    const hits=products.filter(p => terms.every(t=>fold(`${p.name} ${p.platform} ${p.slug}`).includes(t))).slice(0,50);
    if (!hits.length) { const hint=document.createElement('p'); hint.textContent='Ürün bulunamadı.'; hint.style.padding='10px'; results.append(hint); return; }
    hits.forEach(p => {
      const label=document.createElement('label'); label.style.cssText='display:flex;gap:10px;align-items:center;padding:8px 10px;cursor:pointer';
      const box=document.createElement('input');box.type='checkbox';box.checked=current.has(p.slug);
      const text=document.createElement('span');text.textContent=`${p.name} · ${p.platform}`;
      box.addEventListener('change', () => { const next=selected(); if(box.checked){if(next.size>=200){box.checked=false;return;}next.add(p.slug);}else next.delete(p.slug);textarea.value=[...next].join('\n');if(count)count.textContent=String(next.size); });
      label.append(box,text);results.append(label);
    });
  };
  input.addEventListener('input',render); textarea.addEventListener('input',render); render();
})();
