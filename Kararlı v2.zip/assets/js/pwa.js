(() => {
  if ('serviceWorker' in navigator && window.isSecureContext) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js', { scope: '/' }).catch(() => {}), { once: true });
  }
  const button = document.querySelector('[data-pwa-install]');
  const note = document.querySelector('[data-pwa-help]');
  if (!button) return;
  let installPrompt = null;
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  const isiOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  if (!isStandalone && isiOS) button.hidden = false;
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault(); installPrompt = event; button.hidden = false;
  });
  button.addEventListener('click', async () => {
    if (installPrompt) {
      const prompt = installPrompt; installPrompt = null;
      try { await prompt.prompt(); await prompt.userChoice; } catch (_) {}
      button.hidden = true;
    } else if (isiOS && note) {
      note.textContent = 'Safari’de Paylaş düğmesine dokun, ardından Ana Ekrana Ekle’yi seç.';
      note.hidden = false;
    }
  });
  window.addEventListener('appinstalled', () => { installPrompt = null; button.hidden = true; if (note) note.hidden = true; });
})();
