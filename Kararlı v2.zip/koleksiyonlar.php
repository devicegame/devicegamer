<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/collections.php';
require_once __DIR__ . '/partials/dcoin-storefront.php';
$rows=dg_collections_read();
$active=array_values(array_filter($rows, static fn(array $row): bool => !empty($row['active'])));
$id=(string)($_GET['id']??''); $collection=null;
if ($id !== '') {
    foreach($active as $row) if (($row['id']??'')===$id) { $collection=$row; break; }
    if (!$collection) { http_response_code(404); }
}
$allProducts=shop_products(); $catalog=[];
foreach($allProducts as $p) $catalog[(string)$p['slug']]=$p;
$collectionProducts=[];
if ($collection) foreach ((array)($collection['products']??[]) as $slug) if(isset($catalog[$slug])) $collectionProducts[]=$catalog[$slug];
$page_title=$collection ? (string)$collection['title'].' — Koleksiyonlar' : 'Koleksiyonlar';
$page_meta_desc=$collection ? (string)($collection['description']??'Device Game oyun seçkisi.') : 'Device Game tarafından hazırlanan oyun ve mağaza koleksiyonları.';
$page_canonical=$id !== '' && !$collection ? false : 'koleksiyonlar.php'.($collection ? '?id='.rawurlencode($id) : '');
$page_robots=$id !== '' && !$collection ? 'noindex,nofollow' : '';
$page_css=['shop.css','assets/css/dcoin.css','assets/css/collections.css']; $body_class='shop-page dcoin-page';
$dg_context=$collection ? dg_storefront_context($allProducts,'koleksiyonlar.php?id='.rawurlencode($id)) : null;
include __DIR__ . '/header.php';
?>
<section class="dg-collections">
<?php if ($id !== '' && !$collection): ?>
<p class="eyebrow">Koleksiyonlar</p><h1>Bu koleksiyon bulunamadı.</h1><p>Yayından kaldırılmış veya adresi değişmiş olabilir.</p><a class="btn btn-primary" href="koleksiyonlar.php">Tüm koleksiyonlara dön</a>
<?php elseif ($collection): ?>
<a class="dg-collection-back" href="koleksiyonlar.php">← Tüm koleksiyonlar</a><p class="eyebrow">Device Game seçkisi</p><h1><?= e($collection['title']) ?></h1>
<?php if (!empty($collection['description'])): ?><p class="dg-collection-lead"><?= e($collection['description']) ?></p><?php endif; ?>
<p class="dg-collection-count"><?= count($collectionProducts) ?> ürün</p>
<div class="p-grid"><?php if (!$collectionProducts): ?><div class="empty-state"><h2>Bu koleksiyonda henüz ürün yok.</h2><a class="btn btn-primary" href="shop.php">Mağazaya göz at</a></div><?php endif; ?>
<?php foreach($collectionProducts as $index=>$product): include __DIR__ . '/partials/product-card.php'; endforeach; ?></div>
<?php else: ?>
<p class="eyebrow">Device Game seçkileri</p><h1>Oyun dünyasını keşfet.</h1><p class="dg-collection-lead">Senin için bir araya getirdiğimiz oyunları ve ürünleri keşfet.</p>
<div class="dg-collection-grid">
<?php if (!$active): ?><div class="empty-state"><h2>Yeni koleksiyonlar yakında.</h2><p>Bu sırada mağazadaki tüm ürünlere göz atabilirsin.</p><a class="btn btn-primary" href="shop.php">Mağazaya git</a></div><?php endif; ?>
<?php foreach(array_reverse($active) as $row):
 $found=[]; foreach((array)($row['products']??[]) as $slug) if(isset($catalog[$slug])) $found[]=$catalog[$slug];
 $image=$found ? shop_display_image($found[0]) : ''; ?>
<a class="dg-collection-card" href="koleksiyonlar.php?id=<?= rawurlencode((string)$row['id']) ?>">
<div class="dg-collection-art"><?php if ($image !== ''): ?><img src="<?= e($image) ?>" alt="" loading="lazy" decoding="async"><?php endif; ?><span class="dg-collection-art-label">DEVICE GAME / SEÇKİ</span></div>
<div class="dg-collection-body"><span class="dg-collection-meta"><?= count($found) ?> ÜRÜN</span><h2><?= e($row['title']??'') ?></h2><p><?= e($row['description']??'') ?></p><span class="dg-collection-link">Koleksiyonu keşfet ↗</span></div></a>
<?php endforeach; ?></div>
<?php endif; ?>
</section>
<?php if ($dg_context) dg_storefront_render_assets($dg_context); include __DIR__ . '/footer.php'; ?>
