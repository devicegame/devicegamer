<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/lib/favorites.php';
require_login(); $user = current_user();
if (!$user || !empty($user['is_banned'])) { http_response_code(403); exit; }
$favorites = dg_favorite_items((int)$user['id']);
$page_title = 'Favorilerim'; $page_canonical = false; $page_robots = 'noindex,nofollow'; $page_css = ['shop.css']; $body_class = 'shop-page';
include __DIR__ . '/header.php';
?>
<section class="order-done" style="max-width:950px;text-align:left">
<p class="eyebrow">Mağaza</p><h1>Favorilerim</h1><p>Favori ürünlerinin fiyatı düştüğünde site içi bildirim ve e-posta alırsın.</p>
<?php $flash = flash_get(); $err = flash_error_get(); if ($flash): ?><p role="status"><?= e($flash['msg'] ?? '') ?></p><?php endif; if ($err): ?><p role="alert"><?= e($err) ?></p><?php endif; ?>
<?php if (!$favorites): ?><p>Henüz favori ürünün yok.</p><?php endif; ?>
<?php foreach ($favorites as $slug => $fav): $p = shop_product((string)$slug); if (!$p) continue; ?>
<article style="display:flex;gap:1rem;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:1rem;border-bottom:1px solid rgba(255,255,255,.14)">
<div><a href="product.php?slug=<?= rawurlencode((string)$slug) ?>"><strong><?= e($p['name']) ?></strong></a><br><span><?= e(money($p['price'])) ?></span></div>
<form method="post" action="favorite.php"><?= csrf_field() ?><input type="hidden" name="slug" value="<?= e($slug) ?>"><input type="hidden" name="action" value="remove"><input type="hidden" name="return" value="favorites"><button type="submit" class="btn btn-ghost">Favorilerden çıkar</button></form></article>
<?php endforeach; ?>
<p><a class="btn btn-primary" href="shop.php">Mağazaya dön</a></p></section>
<?php include __DIR__ . '/footer.php'; ?>
