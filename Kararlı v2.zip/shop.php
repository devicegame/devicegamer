<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/partials/dcoin-storefront.php';

$page_title = 'Mağaza';
$page_meta_desc = 'Oyun keyleri, premium hesaplar, abonelikler ve Device Game imzalı ekipmanlar. Sepetini oluştur, siparişini WhatsApp üzerinden saniyeler içinde tamamla.';
$page_css = ['shop.css', 'assets/css/dcoin.css'];
$body_class = 'shop-page dcoin-page';

$categories = shop_categories();
$all_products = shop_products();
$active_category = isset($_GET['kategori']) ? (string)$_GET['kategori'] : '';
if ($active_category !== '' && !isset($categories[$active_category])) $active_category = '';
$query = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 120, 'UTF-8');
$sort = (string)($_GET['sirala'] ?? '');
if (!in_array($sort, ['', 'ucuz', 'pahali', 'yeni'], true)) $sort = '';
$platform_labels = ['pc' => 'PC', 'steam' => 'Steam', 'playstation' => 'PlayStation',
    'xbox' => 'Xbox', 'switch' => 'Nintendo Switch', 'epic' => 'Epic Games', 'gog' => 'GOG'];
$region_labels = ['global' => 'Global', 'turkiye' => 'Türkiye', 'avrupa' => 'Avrupa',
    'abd' => 'ABD', 'belirtilmemis' => 'Belirtilmemiş'];
$platform = (string)($_GET['platform'] ?? '');
$region = (string)($_GET['bolge'] ?? '');
if ($platform !== '' && !isset($platform_labels[$platform])) $platform = '';
if ($region !== '' && !isset($region_labels[$region])) $region = '';
$price_param = static function ($value): string {
    $value = trim((string)$value);
    if ($value === '' || !preg_match('/^\d{1,7}$/', $value)) return '';
    return (string)max(0, min(1000000, (int)$value));
};
$min_price = $price_param($_GET['min_fiyat'] ?? '');
$max_price = $price_param($_GET['max_fiyat'] ?? '');
$stock_only = (string)($_GET['stok'] ?? '') === '1';
$requested_page = max(1, (int)($_GET['sayfa'] ?? 1));
$filter_state = [
    'kategori' => $active_category, 'q' => $query, 'sirala' => $sort,
    'platform' => $platform, 'bolge' => $region, 'min_fiyat' => $min_price,
    'max_fiyat' => $max_price, 'stok' => $stock_only ? '1' : '',
];
$dg_login_params = array_filter($filter_state + ['sayfa' => $requested_page > 1 ? $requested_page : ''],
    static fn($value): bool => $value !== '');
$dg_login_query = http_build_query($dg_login_params, '', '&', PHP_QUERY_RFC3986);
$dg_login_next = 'shop.php' . ($dg_login_query !== '' ? '?' . $dg_login_query : '');
$dg_context = dg_storefront_context($all_products, $dg_login_next);
$items_by_slug = (array)($dg_context['items_by_slug'] ?? []);

$available_platforms = [];
$available_regions = [];
$all_counts = [];
foreach ($all_products as $p) {
    $all_counts[$p['category']] = ($all_counts[$p['category']] ?? 0) + 1;
    foreach (shop_product_platforms($p) as $key) $available_platforms[$key] = true;
    $available_regions[shop_product_region($p)] = true;
}
$products = shop_catalog($active_category, $query, $sort);
$products = array_values(array_filter($products, static function (array $p) use ($platform, $region, $min_price, $max_price, $stock_only, $items_by_slug): bool {
    if ($platform !== '' && !in_array($platform, shop_product_platforms($p), true)) return false;
    if ($region !== '' && shop_product_region($p) !== $region) return false;
    if ($min_price !== '' && (int)$p['price'] < (int)$min_price) return false;
    if ($max_price !== '' && (int)$p['price'] > (int)$max_price) return false;
    if ($stock_only && shop_available_stock($p, $items_by_slug) <= 0) return false;
    return true;
}));
$catalog_total = count($products);
$catalog_per_page = 24;
$catalog_pages = max(1, (int)ceil($catalog_total / $catalog_per_page));
$catalog_page = min($requested_page, $catalog_pages);
$products_page = array_slice($products, ($catalog_page - 1) * $catalog_per_page, $catalog_per_page);
$catalog_url = static function (array $changes = []) use ($filter_state): string {
    return url_with(array_merge($filter_state, $changes));
};
$is_filtered = $active_category !== '' || $query !== '' || $sort !== '' || $platform !== ''
    || $region !== '' || $min_price !== '' || $max_price !== '' || $stock_only;
$page_canonical = false;
if (!$is_filtered || ($active_category !== '' && $query === '' && $sort === '' && $platform === ''
        && $region === '' && $min_price === '' && $max_price === '' && !$stock_only)) {
    $canonical_params = array_filter([
        'kategori' => $active_category, 'sayfa' => $catalog_page > 1 ? $catalog_page : '',
    ], static fn($value): bool => $value !== '');
    $page_canonical = 'shop.php' . ($canonical_params ? '?' . http_build_query($canonical_params, '', '&', PHP_QUERY_RFC3986) : '');
}
$page_robots = ($query !== '' || $sort !== '' || $platform !== '' || $region !== ''
    || $min_price !== '' || $max_price !== '' || $stock_only) ? 'noindex,follow' : '';
$page_og_type = 'website';
$page_og_title = 'Mağaza';
$page_og_desc = $page_meta_desc;

include 'header.php';

?>

<section class="shop-hero">
    <div class="shop-hero-inner">
        <div>
            <p class="eyebrow seq" style="--d:.05s">Device Game Mağaza</p>
            <h1 class="seq" style="--d:.15s">Oyunu seç,<br>gerisini <em>bize bırak.</em></h1>
            <p class="shop-hero-desc seq" style="--d:.3s">
                Oyun keyleri, premium hesaplar ve stüdyo imzalı ekipmanlar.
                Sepetini oluşturup WhatsApp'ta onayla ya da D-Coin bakiyenle hemen al; teslimatı biz hallederiz.
            </p>
            <div class="shop-hero-actions seq" style="--d:.4s">
                <a href="#katalog" class="btn btn-primary">Kataloğa göz at</a>
                <a href="cart.php" class="btn btn-ghost">Sepetim<?php echo cart_count() > 0 ? ' (' . cart_count() . ')' : ''; ?></a>
                <a href="favoriler.php" class="btn btn-ghost">♡ Favorilerim</a>
                <a href="koleksiyonlar.php" class="btn btn-ghost">Koleksiyonlar</a>
            </div>
        </div>

        <div class="hero-stats seq" style="--d:.5s">
            <div class="hero-stat hero-stat-wide">
                <span class="live"><span class="pulse" aria-hidden="true"></span>Sipariş hattı açık</span>
                <span class="live-meta">Ortalama yanıt 4 dk</span>
            </div>
            <div class="hero-stat">
                <b><?php echo count(shop_products()); ?></b>
                <span>seçili ürün</span>
            </div>
            <div class="hero-stat">
                <b>4.9<span style="font-size:1.1rem;color:var(--signal)">/5</span></b>
                <span>müşteri puanı</span>
            </div>
            <div class="hero-stat">
                <b>&lt; 5 dk</b>
                <span>ortalama teslimat</span>
            </div>
            <div class="hero-stat">
                <b>7/24</b>
                <span>WhatsApp sipariş hattı</span>
            </div>
        </div>
    </div>

    <div class="ticker" aria-hidden="true">
        <div class="ticker-track">
            <span>Anında teslimat</span><span>WhatsApp ile sipariş</span><span>Güvenli ödeme</span>
            <span>7 gün destek</span><span>Stüdyo imzalı ürünler</span><span>Türkiye'de üretim</span>
            <span>Anında teslimat</span><span>WhatsApp ile sipariş</span><span>Güvenli ödeme</span>
            <span>7 gün destek</span><span>Stüdyo imzalı ürünler</span><span>Türkiye'de üretim</span>
        </div>
    </div>
</section>

<?php include 'partials/slider.php'; ?>

<?php $spotlight = shop_product('ea-sports-fc-26'); if ($spotlight && !$is_filtered && $catalog_page === 1): ?>
<section class="shop-section" style="padding-top:clamp(2.5rem,5vw,4rem);padding-bottom:0;">
    <article class="spotlight">
        <div class="spotlight-art" data-pattern="<?php echo e($spotlight['pattern']); ?>"
             style="--c1:<?php echo e($spotlight['c1']); ?>;--c2:<?php echo e($spotlight['c2']); ?>;--accent:<?php echo e($spotlight['accent']); ?>">
            <?php echo poster_svg($spotlight, 'spot'); ?>
            <span class="spotlight-tag">Haftanın seçkisi</span>
            <span class="spotlight-glyph" aria-hidden="true"><?php echo e($spotlight['glyph']); ?></span>
            <div class="spotlight-art-foot">
                <span><?php echo e($spotlight['platform']); ?></span>
                <span><?php echo e($spotlight['delivery']); ?></span>
            </div>
        </div>
        <div class="spotlight-body">
            <p class="eyebrow"><?php echo e($categories[$spotlight['category']] ?? ''); ?> · <?php echo e($spotlight['platform']); ?></p>
            <h2><?php echo e($spotlight['name']); ?></h2>
            <p class="muted"><?php echo e($spotlight['desc']); ?></p>
            <ul class="spotlight-features">
                <?php foreach (array_slice($spotlight['features'], 0, 3) as $feature): ?>
                    <li>
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 12 5 5L20 6"/></svg>
                        <?php echo e($feature); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <div class="spotlight-buy">
                <div class="price">
                    <b><?php echo e(money($spotlight['price'])); ?></b>
                    <?php if (!empty($spotlight['old_price'])): ?>
                        <s><?php echo e(money($spotlight['old_price'])); ?></s>
                    <?php endif; ?>
                </div>
                <form method="post" action="cart.php" class="add-form">
                    <input type="hidden" name="csrf" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="action" value="add">
                    <input type="hidden" name="slug" value="<?php echo e($spotlight['slug']); ?>">
                    <input type="hidden" name="qty" value="1">
                    <input type="hidden" name="redirect" value="shop.php">
                    <button type="submit" class="btn btn-primary">Sepete ekle</button>
                </form>
                <a class="btn btn-ghost" href="product.php?slug=<?php echo urlencode($spotlight['slug']); ?>">Ürünü incele</a>
            </div>
            <?php dg_storefront_render_buy(dg_storefront_item($dg_context, $spotlight), $dg_context, 'spotlight'); ?>
        </div>
    </article>
</section>
<?php endif; ?>

<section class="shop-section" id="katalog">
    <div class="shop-section-head">
        <div>
            <p class="eyebrow">Katalog</p>
            <h2>Rafı karıştır.</h2>
        </div>
        <p><?php echo $is_filtered ? 'Filtreye uyan ürünleri listeliyoruz.' : 'Her ürün tek tek test edildi. Fiyatlar KDV dahil, sürpriz yok.'; ?></p>
    </div>

    <form class="filters" method="get" action="shop.php#katalog" role="search">
        <div class="filter-row">
            <div class="chips" aria-label="Ürün kategorileri">
                <a class="chip" href="<?php echo e($catalog_url(['kategori' => '', 'sayfa' => ''])); ?>#katalog"
                   aria-current="<?php echo $active_category === '' ? 'true' : 'false'; ?>">
                    Tümü <small><?php echo count($all_products); ?></small>
                </a>
                <?php foreach ($categories as $key => $label): ?>
                    <?php if ((int)($all_counts[$key] ?? 0) <= 0) continue; ?>
                    <a class="chip" href="<?php echo e($catalog_url(['kategori' => $key, 'sayfa' => ''])); ?>#katalog"
                       aria-current="<?php echo $active_category === $key ? 'true' : 'false'; ?>">
                        <?php echo e($label); ?> <small><?php echo (int)$all_counts[$key]; ?></small>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="filter-row catalog-search-row">
            <label class="search-box">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
                <input type="search" name="q" value="<?php echo e($query); ?>" placeholder="Ürün, platform ya da tür ara" aria-label="Mağazada ara">
                <?php if ($active_category !== ''): ?><input type="hidden" name="kategori" value="<?php echo e($active_category); ?>"><?php endif; ?>
                <button type="submit">Ara</button>
            </label>
            <div class="filter-tools">
                <span class="filter-summary"><strong><?php echo number_format($catalog_total, 0, ',', '.'); ?></strong> ürün listeleniyor</span>
                <div class="select-wrap">
                    <select name="sirala" aria-label="Sıralama" data-sort-select>
                        <option value="" <?php echo $sort === '' ? 'selected' : ''; ?>>Öne çıkanlar</option>
                        <option value="ucuz" <?php echo $sort === 'ucuz' ? 'selected' : ''; ?>>Fiyat: artan</option>
                        <option value="pahali" <?php echo $sort === 'pahali' ? 'selected' : ''; ?>>Fiyat: azalan</option>
                        <option value="yeni" <?php echo $sort === 'yeni' ? 'selected' : ''; ?>>En yeni</option>
                    </select>
                </div>
                <button type="submit" class="chip" data-sort-submit>Sırala</button>
            </div>
        </div>
        <div class="catalog-filter-panel" aria-label="Mağaza filtreleri">
            <div class="catalog-filter-heading"><strong>Filtreler</strong><span>Aradığın oyunu daha hızlı bul.</span></div>
            <div class="catalog-filter-grid">
                <label class="catalog-field"><span>Platform</span>
                    <select name="platform">
                        <option value="">Tüm platformlar</option>
                        <?php foreach ($platform_labels as $key => $label): if (empty($available_platforms[$key]) && $platform !== $key) continue; ?>
                            <option value="<?php echo e($key); ?>"<?php echo $platform === $key ? ' selected' : ''; ?>><?php echo e($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="catalog-field"><span>Bölge</span>
                    <select name="bolge">
                        <option value="">Tüm bölgeler</option>
                        <?php foreach ($region_labels as $key => $label): if (empty($available_regions[$key]) && $region !== $key) continue; ?>
                            <option value="<?php echo e($key); ?>"<?php echo $region === $key ? ' selected' : ''; ?>><?php echo e($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label class="catalog-field"><span>En az fiyat (₺)</span>
                    <input type="number" name="min_fiyat" min="0" max="1000000" step="1" inputmode="numeric" placeholder="0" value="<?php echo e($min_price); ?>">
                </label>
                <label class="catalog-field"><span>En çok fiyat (₺)</span>
                    <input type="number" name="max_fiyat" min="0" max="1000000" step="1" inputmode="numeric" placeholder="Üst sınır" value="<?php echo e($max_price); ?>">
                </label>
            </div>
            <div class="catalog-filter-footer">
                <label class="catalog-stock-check"><input type="checkbox" name="stok" value="1"<?php echo $stock_only ? ' checked' : ''; ?>> <span>Yalnızca stokta olanlar</span></label>
                <div class="catalog-filter-actions"><a href="shop.php#katalog">Temizle</a><button type="submit" class="btn btn-primary">Filtreleri uygula</button></div>
            </div>
            <p class="catalog-filter-note">Bölge, ürün bilgisinde açıkça belirtilen değerden; stok ise varsa güncel D-Coin kaydından alınır. TL siparişlerinde stok WhatsApp'ta doğrulanır.</p>
        </div>
    </form>

    <div class="p-grid">
        <?php if (!$products_page): ?>
            <div class="empty-state">
                <h3>Aradığını bulamadık.</h3>
                <p>Filtreleri temizleyebilir veya farklı bir kelime deneyebilirsin.</p>
                <a class="text-link" href="shop.php#katalog">Filtreleri temizle</a>
                <a class="btn btn-primary" href="<?php echo e(wa_link($whatsapp, 'Merhaba, aradığım ürünü mağazada bulamadım. Yardımcı olur musunuz?')); ?>" target="_blank" rel="noopener">WhatsApp'tan sor</a>
            </div>
        <?php else: ?>
            <?php foreach ($products_page as $index => $product): ?>
                <?php include 'partials/product-card.php'; ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <?php if ($catalog_pages > 1): ?>
        <?php
        $pagination_window = [];
        foreach ([1, $catalog_page - 2, $catalog_page - 1, $catalog_page, $catalog_page + 1, $catalog_page + 2, $catalog_pages] as $candidate_page) {
            if ($candidate_page >= 1 && $candidate_page <= $catalog_pages && !in_array($candidate_page, $pagination_window, true)) {
                $pagination_window[] = $candidate_page;
            }
        }
        sort($pagination_window);
        $previous_pagination_page = 0;
        ?>
        <nav aria-label="Mağaza sayfaları" style="display:flex;justify-content:center;align-items:center;gap:.5rem;flex-wrap:wrap;margin-top:2rem">
            <?php if ($catalog_page > 1): ?>
                <a class="chip" href="<?php echo e($catalog_url(['sayfa' => $catalog_page - 1])); ?>#katalog">← Önceki</a>
            <?php endif; ?>
            <?php foreach ($pagination_window as $target_page): ?>
                <?php if ($previous_pagination_page > 0 && $target_page > $previous_pagination_page + 1): ?>
                    <span aria-hidden="true">…</span>
                <?php endif; ?>
                <a class="chip" href="<?php echo e($catalog_url(['sayfa' => $target_page])); ?>#katalog"<?php echo $target_page === $catalog_page ? ' aria-current="true"' : ''; ?>><?php echo $target_page; ?></a>
                <?php $previous_pagination_page = $target_page; ?>
            <?php endforeach; ?>
            <?php if ($catalog_page < $catalog_pages): ?>
                <a class="chip" href="<?php echo e($catalog_url(['sayfa' => $catalog_page + 1])); ?>#katalog">Sonraki →</a>
            <?php endif; ?>
        </nav>
        <p style="text-align:center;color:var(--mist);font-size:.88rem;margin-top:.9rem">Sayfa <?php echo $catalog_page; ?> / <?php echo number_format($catalog_pages, 0, ',', '.'); ?> · <?php echo number_format($catalog_total, 0, ',', '.'); ?> ürün</p>
    <?php endif; ?>
</section>

<?php
$viewed_products = [];
foreach (($_SESSION['viewed'] ?? []) as $viewed_slug) {
    $viewed_item = shop_product((string)$viewed_slug);
    if ($viewed_item) {
        $viewed_products[] = $viewed_item;
    }
}
if (count($viewed_products) >= 2):
?>
<section class="shop-section" style="padding-top:0;">
    <div class="shop-section-head">
        <div>
            <p class="eyebrow">Senin için</p>
            <h2>Son baktıkların.</h2>
        </div>
        <p>Kaldığın yerden devam et.</p>
    </div>
    <div class="p-grid">
        <?php foreach (array_slice($viewed_products, 0, 4) as $index => $viewed_card): ?>
            <?php $product = $viewed_card; include 'partials/product-card.php'; ?>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="trust-band">
    <div class="trust-grid">
        <div class="trust-item">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5Z"/></svg>
            <b>Anında teslimat</b>
            <span>Dijital ürünler ödeme onayından sonra dakikalar içinde elinde.</span>
        </div>
        <div class="trust-item">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 4 6v5.5c0 4.6 3.2 8.3 8 9.5 4.8-1.2 8-4.9 8-9.5V6l-8-3Z"/><path d="m9 12 2 2 4-4"/></svg>
            <b>Güvenli sipariş</b>
            <span>Ödemeyi onaylamadan önce her detayı WhatsApp'ta konuşuyoruz.</span>
        </div>
        <div class="trust-item">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10Z"/></svg>
            <b>Gerçek insan destek</b>
            <span>Sipariş öncesi ve sonrası aynı ekip yanıt veriyor.</span>
        </div>
        <div class="trust-item">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            <b>Şeffaf fiyat</b>
            <span>Katalogdaki fiyat neyse ödediğin de o. Gizli ücret yok.</span>
        </div>
    </div>
</section>

<section class="shop-section">
    <div class="shop-section-head">
        <div>
            <p class="eyebrow">Nasıl işliyor?</p>
            <h2>Sipariş üç adım.</h2>
        </div>
        <p>Hesap açmak, form doldurmak, onay beklemek yok. Sepeti tamamla, WhatsApp açılsın.</p>
    </div>
    <div class="p-grid cols-3">
        <article class="p-card" style="padding:1.75rem;">
            <p class="eyebrow" style="margin-bottom:1rem;">01</p>
            <h3 class="p-name" style="font-size:1.35rem;margin-bottom:.6rem;">Sepetini doldur</h3>
            <p class="muted" style="font-size:.92rem;">Beğendiğin ürünleri sepete ekle, adetleri düzenle. Sepet oturum boyunca seninle kalır.</p>
        </article>
        <article class="p-card" style="padding:1.75rem;">
            <p class="eyebrow" style="margin-bottom:1rem;">02</p>
            <h3 class="p-name" style="font-size:1.35rem;margin-bottom:.6rem;">WhatsApp'ta onayla</h3>
            <p class="muted" style="font-size:.92rem;">Sipariş özeti hazır bir mesaj olarak WhatsApp'ta açılır. Göndermen yeterli.</p>
        </article>
        <article class="p-card" style="padding:1.75rem;">
            <p class="eyebrow" style="margin-bottom:1rem;">03</p>
            <h3 class="p-name" style="font-size:1.35rem;margin-bottom:.6rem;">Teslimatı al</h3>
            <p class="muted" style="font-size:.92rem;">Ödemeyi Havale / EFT ile tamamla; dijital teslimatın dakikalar içinde WhatsApp'ına gelsin.</p>
        </article>
    </div>
</section>

<section class="shop-section" style="padding-top:0;">
    <div class="shop-section-head">
        <div>
            <p class="eyebrow">Sık sorulanlar</p>
            <h2>Aklında kalan olmasın.</h2>
        </div>
    </div>
    <div class="faq-list">
        <details class="faq-item">
            <summary>Ödemeyi nasıl yapıyorum?</summary>
            <p>Ödeme tek yöntemle yapılır: Havale / EFT. WhatsApp'ta siparişi onayladıktan sonra banka bilgilerimizi paylaşıyoruz; ödeme onayı gelmeden teslimat yapılmaz, böylece iki taraf da güvende olur.</p>
        </details>
        <details class="faq-item">
            <summary>Key ve hesaplar ne kadar sürede geliyor?</summary>
            <p>Çalışma saatleri içinde dijital teslimatlar ortalama 5 dakika sürüyor, en geç çalışma saati sonunda iletilir. Abonelik kodları stoktan anında gönderilir.</p>
        </details>
        <details class="faq-item">
            <summary>Hesap alırken şifremi vermem gerekiyor mu?</summary>
            <p>Hayır. Hesap ürünlerinde sana kullanıcı adı ve şifre iletilir; mail değişimi sende kalır. VP yüklemesi gibi işlemlerde yalnızca Riot kullanıcı adı istenir.</p>
        </details>
        <details class="faq-item">
            <summary>Ekipman ve baskı ürünleri nasıl teslim ediliyor?</summary>
            <p>Teslimat şeklimiz dijitaldir; key ve hesaplar ödeme onayından sonra WhatsApp üzerinden iletilir. Ekipman ve baskı siparişlerinde kargo detaylarını (adres ve süre) yine WhatsApp konuşmasında birlikte netleştiriyoruz.</p>
        </details>
        <details class="faq-item">
            <summary>İade ve destek nasıl işliyor?</summary>
            <p>Dijital key ve hesaplarda aktivasyon öncesi iade hakkın var. Fiziksel ürünlerde ayıplı ürün için 14 gün içinde değişim yapıyoruz. Her durumda aynı WhatsApp hattından bize ulaşabilirsin.</p>
        </details>
    </div>
</section>

<section class="cta-band">
    <div>
        <p class="eyebrow" style="margin-bottom:1rem;">Karar veremedin mi?</p>
        <h2>Ne alacağını birlikte bulalım.</h2>
        <p>Bütçeni ve oynadığın platformu söyle; kısa yoldan en doğru seçeneği önerelim.</p>
    </div>
    <div class="cta-band-actions">
        <a class="btn btn-primary" href="<?php echo e(wa_link($whatsapp, 'Merhaba! Bütçeme uygun bir oyun/ürün arıyorum, yardımcı olur musunuz?')); ?>" target="_blank" rel="noopener">WhatsApp'tan danış</a>
        <a class="btn btn-ghost" href="contact.php">İletişim sayfası</a>
    </div>
</section>

<?php dg_storefront_render_assets($dg_context); ?>
<?php include 'footer.php'; ?>
