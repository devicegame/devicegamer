<?php
/** cPanel cron: yalnızca komut satırından çalışır. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../lib/social.php';
require_once __DIR__ . '/../lib/mail.php';
require_once __DIR__ . '/../lib/shop.php';
require_once __DIR__ . '/../lib/favorites.php';
if (!dg_mail_prepare()) {
    error_log('[DG mail] Kuyruk dizini kullanılamıyor.');
    exit(1);
}
try {
    try { dg_favorite_price_watch(); } catch (Throwable $e) { error_log('[DG favorites] Fiyat kontrolü başarısız: ' . $e->getMessage()); }
    $result = dg_mail_work(20);
    $heartbeat = dg_mail_root() . '/state/worker-heartbeat.json';
    @file_put_contents($heartbeat, json_encode(['last_run' => time()] + $result), LOCK_EX);
    @chmod($heartbeat, 0600);
    if (!empty($result['failed'])) error_log('[DG mail] Bazı iletiler yeniden denemek üzere kuyrukta.');
} catch (Throwable $e) {
    error_log('[DG mail] Kuyruk işlenemedi.');
    exit(1);
}
