<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/lib/favorites.php';
require_login();
$user = current_user();
if (!$user || !empty($user['is_banned'])) { http_response_code(403); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify((string)($_POST['csrf'] ?? ''))) { http_response_code(403); exit('Güvenlik doğrulaması başarısız.'); }
$slug = (string)($_POST['slug'] ?? ''); $product = shop_product($slug);
$return = (string)($_POST['return'] ?? '') === 'favorites' ? 'favoriler.php' : 'product.php?slug=' . rawurlencode($slug);
if (!$product) { flash_error_set('Ürün bulunamadı.'); header('Location: shop.php', true, 303); exit; }
try { $active = (string)($_POST['action'] ?? '') === 'add'; dg_set_favorite((int)$user['id'], $product, $active); flash_set($active ? 'Ürün favorilerine eklendi.' : 'Ürün favorilerinden kaldırıldı.'); }
catch (Throwable $e) { error_log('[favorite] ' . $e->getMessage()); flash_error_set('Favori işlemi tamamlanamadı.'); }
header('Location: ' . $return, true, 303); exit;
