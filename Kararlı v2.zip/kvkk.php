<?php
$page_title = 'KVKK Aydınlatma Metni';
$page_canonical = 'kvkk.php';
$page_og_type = 'article';
$page_og_title = 'KVKK Aydınlatma Metni';
$page_css = ['legal.css'];
include 'header.php';
?>

<section class="page-head">
    <h1 class="page-title seq" style="--d:.05s">KVKK Aydınlatma Metni</h1>
</section>

<section class="story">
    <div class="story-inner">
        <h2 class="story-heading">Kişisel verileriniz nasıl işleniyor?</h2>
        <div class="story-body">
            <?php include 'legal-nav.php'; ?>

            <p class="lead">
                6698 sayılı Kişisel Verilerin Korunması Kanunu ("KVKK") madde 10 uyarınca aydınlatma
                yükümlülüğümüz kapsamında bilgilendirme.
            </p>

            <div class="story-block">
                <h3>Veri sorumlusu</h3>
                <?php include 'legal-satici.php'; ?>
            </div>

            <div class="story-block">
                <h3>İşlenen kişisel veriler ve hukuki sebepler</h3>
                <ul>
                    <li><strong>Kimlik verileri:</strong> ad soyad — siparişin kurulması ve ifası (KVKK m.5/2-c).</li>
                    <li><strong>İletişim verileri:</strong> e-posta adresi, telefon numarası — hesap, sipariş, teslimat, işlem bildirimleri ve destek süreçleri (m.5/2-c).</li>
                    <li><strong>Hesap ve topluluk verileri:</strong> kullanıcı adı, profil ve bildirim tercihleri — hesabın ve topluluk hizmetinin yürütülmesi.</li>
                    <li><strong>İşlem güvenliği verileri:</strong> IP adresi, oturum kayıtları, tarayıcı bilgisi — site güvenliği ve yasal yükümlülükler (m.5/2-ç, m.5/2-f).</li>
                    <li><strong>Müşteri işlem verileri:</strong> sipariş, ödeme ve teslimat kayıtları — mevzuattan doğan saklama yükümlülükleri (m.5/2-ç).</li>
                    <li><strong>Pazarlama verileri:</strong> yalnızca açık rıza verilmesi hâlinde kampanya ve bilgilendirme iletileri (m.5/2-a).</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Toplama yöntemi</h3>
                <p>
                    Kişisel verileriniz; web sitemiz üzerindeki sipariş ve iletişim formları, WhatsApp
                    hattımız, e-posta iletişimimiz ve otomatik teknik kayıtlar (oturum çerezleri, loglar)
                    aracılığıyla, elektronik ortamda toplanır.
                </p>
            </div>

            <div class="story-block">
                <h3>İşleme amaçları</h3>
                <ul>
                    <li>Siparişin alınması, hazırlanması ve teslim edilmesi.</li>
                    <li>Ödeme, iade ve değişim süreçlerinin yürütülmesi.</li>
                    <li>Sipariş özeti ve durumunun e-postayla bildirilmesi; kullanıcı tercihlerine göre sosyal bildirimlerin iletilmesi.</li>
                    <li>Müşteri desteği ve iletişim taleplerinin karşılanması.</li>
                    <li>Vergi, ticaret ve tüketici mevzuatından doğan yasal yükümlülüklerin yerine getirilmesi.</li>
                    <li>Web sitesinin güvenliğinin sağlanması ve kötüye kullanımın önlenmesi.</li>
                    <li>Açık rıza verilmesi hâlinde kampanya ve duyuruların iletilmesi.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Verilerin aktarılması</h3>
                <p>Kişisel verileriniz; yalnızca aşağıdaki durumlarda ve gerekli ölçüde üçüncü kişilerle paylaşılır:</p>
                <ul>
                    <li>Yasal yükümlülükler kapsamında yetkili kamu kurum ve kuruluşları.</li>
                    <li>Barındırma (hosting), e-posta iletimi ve teknik hizmet sağlayıcıları.</li>
                    <li>Ödeme süreçlerinde bankalar ve finans kuruluşları (Havale/EFT işlemleri).</li>
                    <li>Fiziksel ürün teslimatlarında kargo firmaları.</li>
                </ul>
            </div>

            <div class="story-block">
                <h3>Saklama süreleri</h3>
                <p>
                    Kişisel veriler, işleme amaçları ve ilgili mevzuatta öngörülen yükümlülükler için gerekli süre boyunca saklanır; süreler veri türüne ve yürürlükteki mevzuata göre belirlenir. Pazarlama izni verilmişse geri alınabilir.
                </p>
            </div>

            <div class="story-block">
                <h3>İlgili kişinin hakları (KVKK madde 11)</h3>
                <p>Verilerinizin işlenip işlenmediğini öğrenme ve bilgi talep etme dâhil olmak üzere:</p>
                <ul>
                    <li>Kişisel verilerinizin düzeltilmesini, silinmesini veya yok edilmesini isteme.</li>
                    <li>İşlemenin sınırlandırılmasını talep etme.</li>
                    <li>İşlemeye itiraz etme ve zarara uğramanız hâlinde tazminat talep etme.</li>
                    <li>Ticari elektronik iletilere ilişkin onayınızı her zaman geri çekme.</li>
                </ul>
                <p>
                    Başvurularınızı <a class="text-link" href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                    adresine veya yazılı olarak şirket adresimize iletebilirsiniz. Başvurular en geç
                    <strong>30 gün</strong> içinde sonuçlandırılır.
                </p>
            </div>

            <div class="story-block">
                <h3>Çerezler</h3>
                <p>
                    Oturum ve sepet için teknik çerezler (ör. PHPSESSID), sosyal taslaklar ve kaydırma konumu için tarayıcı depolaması kullanılabilir. Üçüncü taraf içerikler yüklendiğinde ilgili sağlayıcının uygulamaları da geçerli olabilir. Daha fazla bilgi için <a class="text-link" href="gizlilik.php">Gizlilik Politikası</a>'nı inceleyin.
                </p>
            </div>

            <p class="legal-note">
                Sipariş ve hesap işlemlerine ilişkin bildirimler ticari reklam iletilerinden ayrıdır. Sosyal bildirim e-postaları profil ayarlarından kapatılabilir. Ticari elektronik iletiler yalnızca önceden onay veren alıcılara gönderilir; her zaman ret hakkınızı kullanabilirsiniz.
            </p>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
